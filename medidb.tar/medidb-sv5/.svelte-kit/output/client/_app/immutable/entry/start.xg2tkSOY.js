import{a as r}from"../chunks/llEsX-JL.js";import{x as t}from"../chunks/0NnI20nI.js";export{t as load_css,r as start};
