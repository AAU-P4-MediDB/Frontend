import{k as p,E as t}from"./CB3untgv.js";import{B as c}from"./uaT9V7qS.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
