import"../chunks/Bzak7iHL.js";import"../chunks/69_IOA4Y.js";import{a as r,f as a}from"../chunks/BeB8NPMP.js";var i=a("<div>Settings</div>");function e(o){var t=i();r(o,t)}export{e as component};
