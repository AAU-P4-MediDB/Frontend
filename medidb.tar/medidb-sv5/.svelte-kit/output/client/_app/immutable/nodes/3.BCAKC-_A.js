import"../chunks/Bzak7iHL.js";import{F as He,E as Ie,bg as Ve,aF as je,e as qe,u as Xe,bh as Ye,at as Ue,a8 as Ge,D as Ot,ay as Oe,p as Vt,C as wt,b as jt,x as At,ag as Jt,am as Ke,af as Nt,g as x,f as q,s as H,c as z,h as B,B as Rt,n as Qt}from"../chunks/CB3untgv.js";import{p as k,r as Ae,s as X,l as et,a as Re,b as Ce}from"../chunks/bPtIMHYa.js";import{a as P,f as K,c as nt,t as Zt}from"../chunks/BeB8NPMP.js";import{s as ce}from"../chunks/Ca4tGx_X.js";import{d as Wt,e as Je,a as Qe,c as Se,C as Ze,s as tn}from"../chunks/CCHVBBkx.js";/* empty css                */import"../chunks/69_IOA4Y.js";import{b as en,s as me}from"../chunks/BIncqGdJ.js";import{i as Z}from"../chunks/BJPHRiUJ.js";import{e as nn,i as on}from"../chunks/5pqwCMTs.js";import{d as rn,a as ge}from"../chunks/Dgvtnrtq.js";import{i as sn}from"../chunks/Bwu1S3ks.js";import{g as an}from"../chunks/llEsX-JL.js";import{f as cn}from"../chunks/CuUtCWQh.js";import{b as ln}from"../chunks/U_z0ZYdG.js";import{a as fn}from"../chunks/DvePTTNN.js";import{w as dn}from"../chunks/TPiffgTq.js";import{s as ot}from"../chunks/D-Tgu-J5.js";import{I as rt}from"../chunks/Dun8Sln2.js";const un=()=>performance.now(),ct={tick:e=>requestAnimationFrame(e),now:()=>un(),tasks:new Set};function Pe(){const e=ct.now();ct.tasks.forEach(t=>{t.c(e)||(ct.tasks.delete(t),t.f())}),ct.tasks.size!==0&&ct.tick(Pe)}function hn(e){let t;return ct.tasks.size===0&&ct.tick(Pe),{promise:new Promise(n=>{ct.tasks.add(t={c:e,f:n})}),abort(){ct.tasks.delete(t)}}}function zt(e,t){Oe(()=>{e.dispatchEvent(new CustomEvent(t))})}function mn(e){if(e==="float")return"cssFloat";if(e==="offset")return"cssOffset";if(e.startsWith("--"))return e;const t=e.split("-");return t.length===1?t[0]:t[0]+t.slice(1).map(n=>n[0].toUpperCase()+n.slice(1)).join("")}function ve(e){const t={},n=e.split(";");for(const o of n){const[r,s]=o.split(":");if(!r||s===void 0)break;const i=mn(r.trim());t[i]=s.trim()}return t}const gn=e=>e;function vn(e,t,n,o){var y;var r=(e&Ye)!==0,s="both",i,a=t.inert,l=t.style.overflow,c,f;function u(){return Oe(()=>i??(i=n()(t,(o==null?void 0:o())??{},{direction:s})))}var m={is_global:r,in(){t.inert=a,c=oe(t,u(),f,1,()=>{zt(t,"introend"),c==null||c.abort(),c=i=void 0,t.style.overflow=l})},out(w){t.inert=!0,f=oe(t,u(),c,0,()=>{zt(t,"outroend"),w==null||w()})},stop:()=>{c==null||c.abort(),f==null||f.abort()}},d=He;if(((y=d.nodes).t??(y.t=[])).push(m),en){var g=r;if(!g){for(var h=d.parent;h&&(h.f&Ie)!==0;)for(;(h=h.parent)&&(h.f&Ve)===0;);g=!h||(h.f&je)!==0}g&&qe(()=>{Xe(()=>m.in())})}}function oe(e,t,n,o,r){var s=o===1;if(Ue(t)){var i,a=!1;return Ge(()=>{if(!a){var y=t({direction:s?"in":"out"});i=oe(e,y,n,o,r)}}),{abort:()=>{a=!0,i==null||i.abort()},deactivate:()=>i.deactivate(),reset:()=>i.reset(),t:()=>i.t()}}if(n==null||n.deactivate(),!(t!=null&&t.duration)&&!(t!=null&&t.delay))return zt(e,s?"introstart":"outrostart"),r(),{abort:Ot,deactivate:Ot,reset:Ot,t:()=>o};const{delay:l=0,css:c,tick:f,easing:u=gn}=t;var m=[];if(s&&n===void 0&&(f&&f(0,1),c)){var d=ve(c(0,1));m.push(d,d)}var g=()=>1-o,h=e.animate(m,{duration:l,fill:"forwards"});return h.onfinish=()=>{h.cancel(),zt(e,s?"introstart":"outrostart");var y=(n==null?void 0:n.t())??1-o;n==null||n.abort();var w=o-y,_=t.duration*Math.abs(w),O=[];if(_>0){var A=!1;if(c)for(var p=Math.ceil(_/16.666666666666668),E=0;E<=p;E+=1){var T=y+w*u(E/p),D=ve(c(T,1-T));O.push(D),A||(A=D.overflow==="hidden")}A&&(e.style.overflow="hidden"),g=()=>{var M=h.currentTime;return y+w*u(M/_)},f&&hn(()=>{if(h.playState!=="running")return!1;var M=g();return f(M,1-M),!0})}h=e.animate(O,{duration:_,fill:"forwards"}),h.onfinish=()=>{g=()=>o,f==null||f(o,1-o),r()}},{abort:()=>{h&&(h.cancel(),h.effect=null,h.onfinish=Ot)},deactivate:()=>{r=Ot},reset:()=>{o===0&&(f==null||f(1,0))},t:()=>g()}}const yt=Math.min,vt=Math.max,Ht=Math.round,Ft=Math.floor,tt=e=>({x:e,y:e}),pn={left:"right",right:"left",bottom:"top",top:"bottom"};function re(e,t,n){return vt(e,yt(t,n))}function Pt(e,t){return typeof e=="function"?e(t):e}function dt(e){return e.split("-")[0]}function Lt(e){return e.split("-")[1]}function Le(e){return e==="x"?"y":"x"}function le(e){return e==="y"?"height":"width"}function ft(e){const t=e[0];return t==="t"||t==="b"?"y":"x"}function fe(e){return Le(ft(e))}function wn(e,t,n){n===void 0&&(n=!1);const o=Lt(e),r=fe(e),s=le(r);let i=r==="x"?o===(n?"end":"start")?"right":"left":o==="start"?"bottom":"top";return t.reference[s]>t.floating[s]&&(i=Ct(i)),[i,Ct(i)]}function xn(e){const t=Ct(e);return[ie(e),t,ie(t)]}function ie(e){return e.includes("start")?e.replace("start","end"):e.replace("end","start")}const pe=["left","right"],we=["right","left"],yn=["top","bottom"],bn=["bottom","top"];function _n(e,t,n){switch(e){case"top":case"bottom":return n?t?we:pe:t?pe:we;case"left":case"right":return t?yn:bn;default:return[]}}function En(e,t,n,o){const r=Lt(e);let s=_n(dt(e),n==="start",o);return r&&(s=s.map(i=>i+"-"+r),t&&(s=s.concat(s.map(ie)))),s}function Ct(e){const t=dt(e);return pn[t]+e.slice(t.length)}function On(e){return{top:0,right:0,bottom:0,left:0,...e}}function Te(e){return typeof e!="number"?On(e):{top:e,right:e,bottom:e,left:e}}function It(e){const{x:t,y:n,width:o,height:r}=e;return{width:o,height:r,top:n,left:t,right:t+o,bottom:n+r,x:t,y:n}}function xe(e,t,n){let{reference:o,floating:r}=e;const s=ft(t),i=fe(t),a=le(i),l=dt(t),c=s==="y",f=o.x+o.width/2-r.width/2,u=o.y+o.height/2-r.height/2,m=o[a]/2-r[a]/2;let d;switch(l){case"top":d={x:f,y:o.y-r.height};break;case"bottom":d={x:f,y:o.y+o.height};break;case"right":d={x:o.x+o.width,y:u};break;case"left":d={x:o.x-r.width,y:u};break;default:d={x:o.x,y:o.y}}switch(Lt(t)){case"start":d[i]-=m*(n&&c?-1:1);break;case"end":d[i]+=m*(n&&c?-1:1);break}return d}async function An(e,t){var n;t===void 0&&(t={});const{x:o,y:r,platform:s,rects:i,elements:a,strategy:l}=e,{boundary:c="clippingAncestors",rootBoundary:f="viewport",elementContext:u="floating",altBoundary:m=!1,padding:d=0}=Pt(t,e),g=Te(d),y=a[m?u==="floating"?"reference":"floating":u],w=It(await s.getClippingRect({element:(n=await(s.isElement==null?void 0:s.isElement(y)))==null||n?y:y.contextElement||await(s.getDocumentElement==null?void 0:s.getDocumentElement(a.floating)),boundary:c,rootBoundary:f,strategy:l})),_=u==="floating"?{x:o,y:r,width:i.floating.width,height:i.floating.height}:i.reference,O=await(s.getOffsetParent==null?void 0:s.getOffsetParent(a.floating)),A=await(s.isElement==null?void 0:s.isElement(O))?await(s.getScale==null?void 0:s.getScale(O))||{x:1,y:1}:{x:1,y:1},p=It(s.convertOffsetParentRelativeRectToViewportRelativeRect?await s.convertOffsetParentRelativeRectToViewportRelativeRect({elements:a,rect:_,offsetParent:O,strategy:l}):_);return{top:(w.top-p.top+g.top)/A.y,bottom:(p.bottom-w.bottom+g.bottom)/A.y,left:(w.left-p.left+g.left)/A.x,right:(p.right-w.right+g.right)/A.x}}const Rn=50,Cn=async(e,t,n)=>{const{placement:o="bottom",strategy:r="absolute",middleware:s=[],platform:i}=n,a=i.detectOverflow?i:{...i,detectOverflow:An},l=await(i.isRTL==null?void 0:i.isRTL(t));let c=await i.getElementRects({reference:e,floating:t,strategy:r}),{x:f,y:u}=xe(c,o,l),m=o,d=0;const g={};for(let h=0;h<s.length;h++){const y=s[h];if(!y)continue;const{name:w,fn:_}=y,{x:O,y:A,data:p,reset:E}=await _({x:f,y:u,initialPlacement:o,placement:m,strategy:r,middlewareData:g,rects:c,platform:a,elements:{reference:e,floating:t}});f=O??f,u=A??u,g[w]={...g[w],...p},E&&d<Rn&&(d++,typeof E=="object"&&(E.placement&&(m=E.placement),E.rects&&(c=E.rects===!0?await i.getElementRects({reference:e,floating:t,strategy:r}):E.rects),{x:f,y:u}=xe(c,m,l)),h=-1)}return{x:f,y:u,placement:m,strategy:r,middlewareData:g}},Sn=e=>({name:"arrow",options:e,async fn(t){const{x:n,y:o,placement:r,rects:s,platform:i,elements:a,middlewareData:l}=t,{element:c,padding:f=0}=Pt(e,t)||{};if(c==null)return{};const u=Te(f),m={x:n,y:o},d=fe(r),g=le(d),h=await i.getDimensions(c),y=d==="y",w=y?"top":"left",_=y?"bottom":"right",O=y?"clientHeight":"clientWidth",A=s.reference[g]+s.reference[d]-m[d]-s.floating[g],p=m[d]-s.reference[d],E=await(i.getOffsetParent==null?void 0:i.getOffsetParent(c));let T=E?E[O]:0;(!T||!await(i.isElement==null?void 0:i.isElement(E)))&&(T=a.floating[O]||s.floating[g]);const D=A/2-p/2,M=T/2-h[g]/2-1,F=yt(u[w],M),st=yt(u[_],M),Y=F,at=T-h[g]-st,N=T/2-h[g]/2+D,j=re(Y,N,at),b=!l.arrow&&Lt(r)!=null&&N!==j&&s.reference[g]/2-(N<Y?F:st)-h[g]/2<0,R=b?N<Y?N-Y:N-at:0;return{[d]:m[d]+R,data:{[d]:j,centerOffset:N-j-R,...b&&{alignmentOffset:R}},reset:b}}}),Pn=function(e){return e===void 0&&(e={}),{name:"flip",options:e,async fn(t){var n,o;const{placement:r,middlewareData:s,rects:i,initialPlacement:a,platform:l,elements:c}=t,{mainAxis:f=!0,crossAxis:u=!0,fallbackPlacements:m,fallbackStrategy:d="bestFit",fallbackAxisSideDirection:g="none",flipAlignment:h=!0,...y}=Pt(e,t);if((n=s.arrow)!=null&&n.alignmentOffset)return{};const w=dt(r),_=ft(a),O=dt(a)===a,A=await(l.isRTL==null?void 0:l.isRTL(c.floating)),p=m||(O||!h?[Ct(a)]:xn(a)),E=g!=="none";!m&&E&&p.push(...En(a,h,g,A));const T=[a,...p],D=await l.detectOverflow(t,y),M=[];let F=((o=s.flip)==null?void 0:o.overflows)||[];if(f&&M.push(D[w]),u){const N=wn(r,i,A);M.push(D[N[0]],D[N[1]])}if(F=[...F,{placement:r,overflows:M}],!M.every(N=>N<=0)){var st,Y;const N=(((st=s.flip)==null?void 0:st.index)||0)+1,j=T[N];if(j&&(!(u==="alignment"?_!==ft(j):!1)||F.every($=>ft($.placement)===_?$.overflows[0]>0:!0)))return{data:{index:N,overflows:F},reset:{placement:j}};let b=(Y=F.filter(R=>R.overflows[0]<=0).sort((R,$)=>R.overflows[1]-$.overflows[1])[0])==null?void 0:Y.placement;if(!b)switch(d){case"bestFit":{var at;const R=(at=F.filter($=>{if(E){const L=ft($.placement);return L===_||L==="y"}return!0}).map($=>[$.placement,$.overflows.filter(L=>L>0).reduce((L,ht)=>L+ht,0)]).sort(($,L)=>$[1]-L[1])[0])==null?void 0:at[0];R&&(b=R);break}case"initialPlacement":b=a;break}if(r!==b)return{reset:{placement:b}}}return{}}}},Ln=new Set(["left","top"]);async function Tn(e,t){const{placement:n,platform:o,elements:r}=e,s=await(o.isRTL==null?void 0:o.isRTL(r.floating)),i=dt(n),a=Lt(n),l=ft(n)==="y",c=Ln.has(i)?-1:1,f=s&&l?-1:1,u=Pt(t,e);let{mainAxis:m,crossAxis:d,alignmentAxis:g}=typeof u=="number"?{mainAxis:u,crossAxis:0,alignmentAxis:null}:{mainAxis:u.mainAxis||0,crossAxis:u.crossAxis||0,alignmentAxis:u.alignmentAxis};return a&&typeof g=="number"&&(d=a==="end"?g*-1:g),l?{x:d*f,y:m*c}:{x:m*c,y:d*f}}const Mn=function(e){return e===void 0&&(e=0),{name:"offset",options:e,async fn(t){var n,o;const{x:r,y:s,placement:i,middlewareData:a}=t,l=await Tn(t,e);return i===((n=a.offset)==null?void 0:n.placement)&&(o=a.arrow)!=null&&o.alignmentOffset?{}:{x:r+l.x,y:s+l.y,data:{...l,placement:i}}}}},$n=function(e){return e===void 0&&(e={}),{name:"shift",options:e,async fn(t){const{x:n,y:o,placement:r,platform:s}=t,{mainAxis:i=!0,crossAxis:a=!1,limiter:l={fn:w=>{let{x:_,y:O}=w;return{x:_,y:O}}},...c}=Pt(e,t),f={x:n,y:o},u=await s.detectOverflow(t,c),m=ft(dt(r)),d=Le(m);let g=f[d],h=f[m];if(i){const w=d==="y"?"top":"left",_=d==="y"?"bottom":"right",O=g+u[w],A=g-u[_];g=re(O,g,A)}if(a){const w=m==="y"?"top":"left",_=m==="y"?"bottom":"right",O=h+u[w],A=h-u[_];h=re(O,h,A)}const y=l.fn({...t,[d]:g,[m]:h});return{...y,data:{x:y.x-n,y:y.y-o,enabled:{[d]:i,[m]:a}}}}}};function qt(){return typeof window<"u"}function _t(e){return Me(e)?(e.nodeName||"").toLowerCase():"#document"}function V(e){var t;return(e==null||(t=e.ownerDocument)==null?void 0:t.defaultView)||window}function it(e){var t;return(t=(Me(e)?e.ownerDocument:e.document)||window.document)==null?void 0:t.documentElement}function Me(e){return qt()?e instanceof Node||e instanceof V(e).Node:!1}function U(e){return qt()?e instanceof Element||e instanceof V(e).Element:!1}function lt(e){return qt()?e instanceof HTMLElement||e instanceof V(e).HTMLElement:!1}function ye(e){return!qt()||typeof ShadowRoot>"u"?!1:e instanceof ShadowRoot||e instanceof V(e).ShadowRoot}function Tt(e){const{overflow:t,overflowX:n,overflowY:o,display:r}=G(e);return/auto|scroll|overlay|hidden|clip/.test(t+o+n)&&r!=="inline"&&r!=="contents"}function kn(e){return/^(table|td|th)$/.test(_t(e))}function Xt(e){try{if(e.matches(":popover-open"))return!0}catch{}try{return e.matches(":modal")}catch{return!1}}const Dn=/transform|translate|scale|rotate|perspective|filter/,Nn=/paint|layout|strict|content/,gt=e=>!!e&&e!=="none";let te;function de(e){const t=U(e)?G(e):e;return gt(t.transform)||gt(t.translate)||gt(t.scale)||gt(t.rotate)||gt(t.perspective)||!ue()&&(gt(t.backdropFilter)||gt(t.filter))||Dn.test(t.willChange||"")||Nn.test(t.contain||"")}function Fn(e){let t=ut(e);for(;lt(t)&&!bt(t);){if(de(t))return t;if(Xt(t))return null;t=ut(t)}return null}function ue(){return te==null&&(te=typeof CSS<"u"&&CSS.supports&&CSS.supports("-webkit-backdrop-filter","none")),te}function bt(e){return/^(html|body|#document)$/.test(_t(e))}function G(e){return V(e).getComputedStyle(e)}function Yt(e){return U(e)?{scrollLeft:e.scrollLeft,scrollTop:e.scrollTop}:{scrollLeft:e.scrollX,scrollTop:e.scrollY}}function ut(e){if(_t(e)==="html")return e;const t=e.assignedSlot||e.parentNode||ye(e)&&e.host||it(e);return ye(t)?t.host:t}function $e(e){const t=ut(e);return bt(t)?e.ownerDocument?e.ownerDocument.body:e.body:lt(t)&&Tt(t)?t:$e(t)}function St(e,t,n){var o;t===void 0&&(t=[]),n===void 0&&(n=!0);const r=$e(e),s=r===((o=e.ownerDocument)==null?void 0:o.body),i=V(r);if(s){const a=se(i);return t.concat(i,i.visualViewport||[],Tt(r)?r:[],a&&n?St(a):[])}else return t.concat(r,St(r,[],n))}function se(e){return e.parent&&Object.getPrototypeOf(e.parent)?e.frameElement:null}function ke(e){const t=G(e);let n=parseFloat(t.width)||0,o=parseFloat(t.height)||0;const r=lt(e),s=r?e.offsetWidth:n,i=r?e.offsetHeight:o,a=Ht(n)!==s||Ht(o)!==i;return a&&(n=s,o=i),{width:n,height:o,$:a}}function he(e){return U(e)?e:e.contextElement}function xt(e){const t=he(e);if(!lt(t))return tt(1);const n=t.getBoundingClientRect(),{width:o,height:r,$:s}=ke(t);let i=(s?Ht(n.width):n.width)/o,a=(s?Ht(n.height):n.height)/r;return(!i||!Number.isFinite(i))&&(i=1),(!a||!Number.isFinite(a))&&(a=1),{x:i,y:a}}const Bn=tt(0);function De(e){const t=V(e);return!ue()||!t.visualViewport?Bn:{x:t.visualViewport.offsetLeft,y:t.visualViewport.offsetTop}}function Wn(e,t,n){return t===void 0&&(t=!1),!n||t&&n!==V(e)?!1:t}function pt(e,t,n,o){t===void 0&&(t=!1),n===void 0&&(n=!1);const r=e.getBoundingClientRect(),s=he(e);let i=tt(1);t&&(o?U(o)&&(i=xt(o)):i=xt(e));const a=Wn(s,n,o)?De(s):tt(0);let l=(r.left+a.x)/i.x,c=(r.top+a.y)/i.y,f=r.width/i.x,u=r.height/i.y;if(s){const m=V(s),d=o&&U(o)?V(o):o;let g=m,h=se(g);for(;h&&o&&d!==g;){const y=xt(h),w=h.getBoundingClientRect(),_=G(h),O=w.left+(h.clientLeft+parseFloat(_.paddingLeft))*y.x,A=w.top+(h.clientTop+parseFloat(_.paddingTop))*y.y;l*=y.x,c*=y.y,f*=y.x,u*=y.y,l+=O,c+=A,g=V(h),h=se(g)}}return It({width:f,height:u,x:l,y:c})}function Ut(e,t){const n=Yt(e).scrollLeft;return t?t.left+n:pt(it(e)).left+n}function Ne(e,t){const n=e.getBoundingClientRect(),o=n.left+t.scrollLeft-Ut(e,n),r=n.top+t.scrollTop;return{x:o,y:r}}function zn(e){let{elements:t,rect:n,offsetParent:o,strategy:r}=e;const s=r==="fixed",i=it(o),a=t?Xt(t.floating):!1;if(o===i||a&&s)return n;let l={scrollLeft:0,scrollTop:0},c=tt(1);const f=tt(0),u=lt(o);if((u||!u&&!s)&&((_t(o)!=="body"||Tt(i))&&(l=Yt(o)),u)){const d=pt(o);c=xt(o),f.x=d.x+o.clientLeft,f.y=d.y+o.clientTop}const m=i&&!u&&!s?Ne(i,l):tt(0);return{width:n.width*c.x,height:n.height*c.y,x:n.x*c.x-l.scrollLeft*c.x+f.x+m.x,y:n.y*c.y-l.scrollTop*c.y+f.y+m.y}}function Hn(e){return Array.from(e.getClientRects())}function In(e){const t=it(e),n=Yt(e),o=e.ownerDocument.body,r=vt(t.scrollWidth,t.clientWidth,o.scrollWidth,o.clientWidth),s=vt(t.scrollHeight,t.clientHeight,o.scrollHeight,o.clientHeight);let i=-n.scrollLeft+Ut(e);const a=-n.scrollTop;return G(o).direction==="rtl"&&(i+=vt(t.clientWidth,o.clientWidth)-r),{width:r,height:s,x:i,y:a}}const be=25;function Vn(e,t){const n=V(e),o=it(e),r=n.visualViewport;let s=o.clientWidth,i=o.clientHeight,a=0,l=0;if(r){s=r.width,i=r.height;const f=ue();(!f||f&&t==="fixed")&&(a=r.offsetLeft,l=r.offsetTop)}const c=Ut(o);if(c<=0){const f=o.ownerDocument,u=f.body,m=getComputedStyle(u),d=f.compatMode==="CSS1Compat"&&parseFloat(m.marginLeft)+parseFloat(m.marginRight)||0,g=Math.abs(o.clientWidth-u.clientWidth-d);g<=be&&(s-=g)}else c<=be&&(s+=c);return{width:s,height:i,x:a,y:l}}function jn(e,t){const n=pt(e,!0,t==="fixed"),o=n.top+e.clientTop,r=n.left+e.clientLeft,s=lt(e)?xt(e):tt(1),i=e.clientWidth*s.x,a=e.clientHeight*s.y,l=r*s.x,c=o*s.y;return{width:i,height:a,x:l,y:c}}function _e(e,t,n){let o;if(t==="viewport")o=Vn(e,n);else if(t==="document")o=In(it(e));else if(U(t))o=jn(t,n);else{const r=De(e);o={x:t.x-r.x,y:t.y-r.y,width:t.width,height:t.height}}return It(o)}function Fe(e,t){const n=ut(e);return n===t||!U(n)||bt(n)?!1:G(n).position==="fixed"||Fe(n,t)}function qn(e,t){const n=t.get(e);if(n)return n;let o=St(e,[],!1).filter(a=>U(a)&&_t(a)!=="body"),r=null;const s=G(e).position==="fixed";let i=s?ut(e):e;for(;U(i)&&!bt(i);){const a=G(i),l=de(i);!l&&a.position==="fixed"&&(r=null),(s?!l&&!r:!l&&a.position==="static"&&!!r&&(r.position==="absolute"||r.position==="fixed")||Tt(i)&&!l&&Fe(e,i))?o=o.filter(f=>f!==i):r=a,i=ut(i)}return t.set(e,o),o}function Xn(e){let{element:t,boundary:n,rootBoundary:o,strategy:r}=e;const i=[...n==="clippingAncestors"?Xt(t)?[]:qn(t,this._c):[].concat(n),o],a=_e(t,i[0],r);let l=a.top,c=a.right,f=a.bottom,u=a.left;for(let m=1;m<i.length;m++){const d=_e(t,i[m],r);l=vt(d.top,l),c=yt(d.right,c),f=yt(d.bottom,f),u=vt(d.left,u)}return{width:c-u,height:f-l,x:u,y:l}}function Yn(e){const{width:t,height:n}=ke(e);return{width:t,height:n}}function Un(e,t,n){const o=lt(t),r=it(t),s=n==="fixed",i=pt(e,!0,s,t);let a={scrollLeft:0,scrollTop:0};const l=tt(0);function c(){l.x=Ut(r)}if(o||!o&&!s)if((_t(t)!=="body"||Tt(r))&&(a=Yt(t)),o){const d=pt(t,!0,s,t);l.x=d.x+t.clientLeft,l.y=d.y+t.clientTop}else r&&c();s&&!o&&r&&c();const f=r&&!o&&!s?Ne(r,a):tt(0),u=i.left+a.scrollLeft-l.x-f.x,m=i.top+a.scrollTop-l.y-f.y;return{x:u,y:m,width:i.width,height:i.height}}function ee(e){return G(e).position==="static"}function Ee(e,t){if(!lt(e)||G(e).position==="fixed")return null;if(t)return t(e);let n=e.offsetParent;return it(e)===n&&(n=n.ownerDocument.body),n}function Be(e,t){const n=V(e);if(Xt(e))return n;if(!lt(e)){let r=ut(e);for(;r&&!bt(r);){if(U(r)&&!ee(r))return r;r=ut(r)}return n}let o=Ee(e,t);for(;o&&kn(o)&&ee(o);)o=Ee(o,t);return o&&bt(o)&&ee(o)&&!de(o)?n:o||Fn(e)||n}const Gn=async function(e){const t=this.getOffsetParent||Be,n=this.getDimensions,o=await n(e.floating);return{reference:Un(e.reference,await t(e.floating),e.strategy),floating:{x:0,y:0,width:o.width,height:o.height}}};function Kn(e){return G(e).direction==="rtl"}const Jn={convertOffsetParentRelativeRectToViewportRelativeRect:zn,getDocumentElement:it,getClippingRect:Xn,getOffsetParent:Be,getElementRects:Gn,getClientRects:Hn,getDimensions:Yn,getScale:xt,isElement:U,isRTL:Kn};function We(e,t){return e.x===t.x&&e.y===t.y&&e.width===t.width&&e.height===t.height}function Qn(e,t){let n=null,o;const r=it(e);function s(){var a;clearTimeout(o),(a=n)==null||a.disconnect(),n=null}function i(a,l){a===void 0&&(a=!1),l===void 0&&(l=1),s();const c=e.getBoundingClientRect(),{left:f,top:u,width:m,height:d}=c;if(a||t(),!m||!d)return;const g=Ft(u),h=Ft(r.clientWidth-(f+m)),y=Ft(r.clientHeight-(u+d)),w=Ft(f),O={rootMargin:-g+"px "+-h+"px "+-y+"px "+-w+"px",threshold:vt(0,yt(1,l))||1};let A=!0;function p(E){const T=E[0].intersectionRatio;if(T!==l){if(!A)return i();T?i(!1,T):o=setTimeout(()=>{i(!1,1e-7)},1e3)}T===1&&!We(c,e.getBoundingClientRect())&&i(),A=!1}try{n=new IntersectionObserver(p,{...O,root:r.ownerDocument})}catch{n=new IntersectionObserver(p,O)}n.observe(e)}return i(!0),s}function Zn(e,t,n,o){o===void 0&&(o={});const{ancestorScroll:r=!0,ancestorResize:s=!0,elementResize:i=typeof ResizeObserver=="function",layoutShift:a=typeof IntersectionObserver=="function",animationFrame:l=!1}=o,c=he(e),f=r||s?[...c?St(c):[],...t?St(t):[]]:[];f.forEach(w=>{r&&w.addEventListener("scroll",n,{passive:!0}),s&&w.addEventListener("resize",n)});const u=c&&a?Qn(c,n):null;let m=-1,d=null;i&&(d=new ResizeObserver(w=>{let[_]=w;_&&_.target===c&&d&&t&&(d.unobserve(t),cancelAnimationFrame(m),m=requestAnimationFrame(()=>{var O;(O=d)==null||O.observe(t)})),n()}),c&&!l&&d.observe(c),t&&d.observe(t));let g,h=l?pt(e):null;l&&y();function y(){const w=pt(e);h&&!We(h,w)&&n(),h=w,g=requestAnimationFrame(y)}return n(),()=>{var w;f.forEach(_=>{r&&_.removeEventListener("scroll",n),s&&_.removeEventListener("resize",n)}),u==null||u(),(w=d)==null||w.disconnect(),d=null,l&&cancelAnimationFrame(g)}}const to=Mn,eo=$n,no=Pn,oo=Sn,ro=(e,t,n)=>{const o=new Map,r={platform:Jn,...n},s={...r.platform,_c:o};return Cn(e,t,{...r,platform:s})};function io(e){const t=Math.cos(e*Math.PI*.5);return Math.abs(t)<1e-14?1:1-t}const so=e=>e;function ao(e,{delay:t=0,duration:n=400,easing:o=so}={}){const r=+getComputedStyle(e).opacity;return{delay:t,duration:n,easing:o,css:s=>`opacity: ${s*r}`}}var co=K("<div></div>");function lo(e,t){Vt(t,!0);let n=k(t,"placement",3,"top"),o=k(t,"class",3,"");const r=c=>c?`${c}px`:"";function s(c){const f=window.getComputedStyle(c);return Math.max(parseFloat(f.borderLeftWidth),parseFloat(f.borderBottomWidth))-.3}const i={left:" rotate-45",right:" -rotate-135",top:" rotate-135",bottom:" -rotate-45"};function a(c){At(()=>{c.style.left=r(t.cords.x),c.style.top=r(t.cords.y),c.style.right="",c.style.bottom="";let f=dt(Ct(n()));c.style[f]=r(-c.offsetWidth/2-s(c)),c.classList.remove("rotate-45","-rotate-45","rotate-135","-rotate-135"),c.className+=i[f]})}var l=co();fn(l,c=>a==null?void 0:a(c)),wt(()=>Wt(l,1,`popover-arrow clip pointer-events-none absolute block h-[10px] w-[10px] border-b border-l border-inherit bg-inherit text-inherit ${o()??""}`)),P(e,l),jt()}function fo(e,t,n){let o=null;function r(l,c,f){o=requestAnimationFrame(u=>{if(u-(f||0)<n())return r(l,c,f);o=null,l(...c)})}function s(){o!==null&&(cancelAnimationFrame(o),o=null)}return[(...l)=>{s(),r(e,l,performance.now())},(...l)=>{s(),r(t,l,performance.now())}]}var uo=K("<div><!> <!></div>"),ho=K('<div hidden=""></div> <!>',1);function mo(e,t){Vt(t,!0);const n=200,o=8;let r=k(t,"triggerDelay",3,n),s=k(t,"trigger",3,"click"),i=k(t,"placement",3,"top"),a=k(t,"offset",3,o),l=k(t,"arrow",3,!1),c=k(t,"yOnly",3,!1),f=k(t,"strategy",3,"absolute"),u=k(t,"role",3,"tooltip"),m=k(t,"middlewares",19,()=>[no(),eo()]),d=k(t,"class",3,""),g=k(t,"arrowClass",3,""),h=k(t,"isOpen",15,!1),y=k(t,"transition",3,ao),w=Ae(t,["$$slots","$$events","$$legacy","triggeredBy","triggerDelay","trigger","placement","offset","arrow","yOnly","strategy","role","reference","middlewares","class","arrowClass","isOpen","transitionParams","transition","onbeforetoggle","ontoggle","onclose","children"]),_=!0,O=Rt(()=>s()==="click"),A=Rt(()=>s()==="hover"),p=Jt(null),E=null,T=null,D=[],M=Jt(Ke({placement:"top",cords:{x:0,y:0}}));At(()=>{Nt(M,{placement:i(),cords:{x:0,y:0}},!0)}),At(()=>{t.reference&&x(p)&&(T=x(p).ownerDocument.querySelector(t.reference))});let F=Jt(null);At(()=>{x(p)&&Nt(F,x(p).querySelector(".popover-arrow"),!0)});let st=Rt(()=>{const v=[...m(),to(a())];return x(F)&&v.push(oo({element:x(F)})),v});const Y={duration:100,easing:io},at=Rt(()=>t.transitionParams??Y),N=v=>v?`${v}px`:"";function j(){if(!(!E||!x(p)))return ro(T??E,x(p),{placement:i(),middleware:x(st),strategy:f()}).then(({x:v,y:C,middlewareData:{arrow:S},placement:W,strategy:Q})=>{x(p)&&(Object.assign(x(p).style,{position:Q,left:c()?"0":N(v),right:"auto",top:N(C)}),S&&x(F)&&Nt(M,{placement:W,cords:{x:S.x,y:S.y}},!0))})}async function b(v){var C,S;v.preventDefault(),v.target!==E&&D.includes(v.target)&&(E=v.target,h()&&((C=x(p))==null||C.dispatchEvent(new ToggleEvent("beforetoggle",{newState:"open",oldState:"open"})),await j(),(S=x(p))==null||S.dispatchEvent(new ToggleEvent("toggle",{newState:"open",oldState:"open"})))),v.type==="mousedown"?h(!h()):h(!0)}async function R(v){var C,S;if(s()==="click"&&v.type==="focusout"){const W=v.relatedTarget;if(x(p)&&W&&x(p).contains(W)||!W)return}(v==null?void 0:v.type)==="mouseleave"&&((C=x(p))!=null&&C.contains(x(p).ownerDocument.activeElement))||(v==null?void 0:v.type)==="focusout"&&((S=x(p))!=null&&S.contains(x(p).ownerDocument.activeElement))||h(!1)}const[$,L]=fo(b,R,()=>r());function ht(v){var S;if(!E||!x(p))return;const C=Object.assign(v,{trigger:E});(S=t.onbeforetoggle)==null||S.call(t,C)}At(()=>{let v=null;return h()&&x(p)&&E&&(v=Zn(T??E,x(p),j),x(p).ownerDocument.addEventListener("click",$t),x(p).ownerDocument.addEventListener("keydown",Mt)),()=>{var C,S;v==null||v(),v=null,(C=x(p))==null||C.ownerDocument.removeEventListener("click",$t),(S=x(p))==null||S.ownerDocument.removeEventListener("keydown",Mt)}});function Gt(v){var S,W;if(!E)return;h(v.newState==="open");const C=Object.assign(v,{trigger:E});(S=t.ontoggle)==null||S.call(t,C),v.newState==="closed"&&((W=t.onclose)==null||W.call(t,C))}function Kt(v){const C=[["focusin",$,_],["focusout",L,_],["mousedown",$,x(O)],["mouseenter",$,x(A)],["mouseleave",L,x(A)]];if(t.triggeredBy?D=[...v.ownerDocument.querySelectorAll(t.triggeredBy)]:v.previousElementSibling?D=[v.previousElementSibling]:v.parentElement&&(D=[v.parentElement]),!D.length){console.error("No triggers found.",t.triggeredBy);return}return E=D[0],D.forEach(S=>{S.tabIndex<0&&(S.tabIndex=0);for(const[W,Q,Et]of C)Et&&S.addEventListener(W,Q)}),()=>{D.forEach(S=>{for(const[W,Q,Et]of C)Et&&S.removeEventListener(W,Q)})}}function Mt(v){v.key==="Escape"&&h(!1)}function $t(v){if(!x(p))return;const C=v.composedPath(),S=C.includes(x(p)),W=D.some(Q=>C.includes(Q));!S&&!W&&(L(v),h(!1))}var kt=ho(),J=q(kt);Je(J,()=>Kt);var mt=H(J,2);{var Dt=v=>{var C=uo(),S=()=>{var I;return(I=x(p))==null?void 0:I.showPopover()},W=()=>{var I;return(I=x(p))==null?void 0:I.hidePopover()};Qe(C,I=>({popover:"manual",role:u(),onfocusout:L,onmouseleave:x(A)?L:void 0,onmouseenter:x(A)?$:void 0,class:I,onintrostart:S,onbeforetoggle:ht,ontoggle:Gt,onoutroend:W,...w,[Ze]:{"overflow-visible":!0}}),[()=>Se(d())]);var Q=z(C);ce(Q,()=>t.children);var Et=H(Q,2);{var ze=I=>{lo(I,X(()=>x(M),{get class(){return g()}}))};Z(Et,I=>{l()&&I(ze)})}B(C),ln(C,I=>Nt(p,I),()=>x(p)),vn(3,C,y,()=>x(at)),P(v,C)};Z(mt,v=>{h()&&v(Dt)})}P(e,kt),jt()}var go=K('<div class="pointer-events-none"><!></div>');function ne(e,t){Vt(t,!0);let n=k(t,"type",3,"dark"),o=k(t,"color",3,void 0),r=k(t,"trigger",3,"hover"),s=k(t,"arrow",3,!0),i=k(t,"placement",3,"top"),a=k(t,"isOpen",15,!1),l=Ae(t,["$$slots","$$events","$$legacy","type","color","trigger","arrow","children","placement","onbeforetoggle","class","isOpen"]);const c=Rt(()=>cn({color:o(),type:n(),class:Se(t.class)}));function f(u){var m;u.target instanceof HTMLElement&&u.target.querySelectorAll('a, button, input, textarea, select, details, [tabindex], [contenteditable="true"]').forEach(d=>d.setAttribute("tabindex","-1")),(m=t.onbeforetoggle)==null||m.call(t,u)}mo(e,X(()=>l,{get placement(){return i()},get trigger(){return r()},get arrow(){return s()},get class(){return x(c)},onbeforetoggle:f,get isOpen(){return a()},set isOpen(u){a(u)},children:(u,m)=>{var d=go(),g=z(d);ce(g,()=>t.children),B(d),P(u,d)},$$slots:{default:!0}})),jt()}function vo(e,t){const n=et(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const o=[["path",{d:"M8 2v4"}],["path",{d:"M16 2v4"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2"}],["path",{d:"M3 10h18"}],["path",{d:"M8 14h.01"}],["path",{d:"M12 14h.01"}],["path",{d:"M16 14h.01"}],["path",{d:"M8 18h.01"}],["path",{d:"M12 18h.01"}],["path",{d:"M16 18h.01"}]];rt(e,X({name:"calendar-days"},()=>n,{get iconNode(){return o},children:(r,s)=>{var i=nt(),a=q(i);ot(a,t,"default",{}),P(r,i)},$$slots:{default:!0}}))}function po(e,t){const n=et(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const o=[["path",{d:"m15 18-6-6 6-6"}]];rt(e,X({name:"chevron-left"},()=>n,{get iconNode(){return o},children:(r,s)=>{var i=nt(),a=q(i);ot(a,t,"default",{}),P(r,i)},$$slots:{default:!0}}))}function wo(e,t){const n=et(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const o=[["path",{d:"m9 18 6-6-6-6"}]];rt(e,X({name:"chevron-right"},()=>n,{get iconNode(){return o},children:(r,s)=>{var i=nt(),a=q(i);ot(a,t,"default",{}),P(r,i)},$$slots:{default:!0}}))}function xo(e,t){const n=et(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const o=[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"}],["path",{d:"M12 11h4"}],["path",{d:"M12 16h4"}],["path",{d:"M8 11h.01"}],["path",{d:"M8 16h.01"}]];rt(e,X({name:"clipboard-list"},()=>n,{get iconNode(){return o},children:(r,s)=>{var i=nt(),a=q(i);ot(a,t,"default",{}),P(r,i)},$$slots:{default:!0}}))}function yo(e,t){const n=et(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const o=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"}]];rt(e,X({name:"house"},()=>n,{get iconNode(){return o},children:(r,s)=>{var i=nt(),a=q(i);ot(a,t,"default",{}),P(r,i)},$$slots:{default:!0}}))}function bo(e,t){const n=et(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const o=[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1"}]];rt(e,X({name:"layout-dashboard"},()=>n,{get iconNode(){return o},children:(r,s)=>{var i=nt(),a=q(i);ot(a,t,"default",{}),P(r,i)},$$slots:{default:!0}}))}function _o(e,t){const n=et(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const o=[["path",{d:"M16 5H3"}],["path",{d:"M16 12H3"}],["path",{d:"M11 19H3"}],["path",{d:"m15 18 2 2 4-4"}]];rt(e,X({name:"list-check"},()=>n,{get iconNode(){return o},children:(r,s)=>{var i=nt(),a=q(i);ot(a,t,"default",{}),P(r,i)},$$slots:{default:!0}}))}function Eo(e,t){const n=et(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const o=[["path",{d:"m16 17 5-5-5-5"}],["path",{d:"M21 12H9"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"}]];rt(e,X({name:"log-out"},()=>n,{get iconNode(){return o},children:(r,s)=>{var i=nt(),a=q(i);ot(a,t,"default",{}),P(r,i)},$$slots:{default:!0}}))}function Bt(e,t){const n=et(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const o=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915"}],["circle",{cx:"12",cy:"12",r:"3"}]];rt(e,X({name:"settings"},()=>n,{get iconNode(){return o},children:(r,s)=>{var i=nt(),a=q(i);ot(a,t,"default",{}),P(r,i)},$$slots:{default:!0}}))}function Oo(e,t){const n=et(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v1.0.1 - ISC
 *
 * ISC License
 *
 * Copyright (c) 2026 Lucide Icons and Contributors
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The following Lucide icons are derived from the Feather project:
 *
 * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
 *
 * The MIT License (MIT) (for the icons listed above)
 *
 * Copyright (c) 2013-present Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const o=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2"}],["path",{d:"M9 8h7"}],["path",{d:"M8 12h6"}],["path",{d:"M11 16h5"}]];rt(e,X({name:"square-chart-gantt"},()=>n,{get iconNode(){return o},children:(r,s)=>{var i=nt(),a=q(i);ot(a,t,"default",{}),P(r,i)},$$slots:{default:!0}}))}const ae=dn(!0);var Ao=K('<span class="font-bold text-xl overflow-hidden whitespace-nowrap">MediDB</span>'),Ro=K('<span class="ml-4 font-medium overflow-hidden whitespace-nowrap"> </span>'),Co=K('<a class="flex items-center p-3 rounded-xl hover:bg-light hover:text-darker transition-colors group"><div class="flex items-center justify-center min-w-8"><!></div> <!></a> <!>',1),So=K('<span class="ml-4 font-medium overflow-hidden whitespace-nowrap">Settings</span>'),Po=K('<span class="ml-4 font-medium overflow-hidden whitespace-nowrap">Logout</span>'),Lo=K('<aside><div class="flex items-center p-4 h-16 transition-all duration-300"><!> <button><!></button></div> <nav class="px-3 space-y-2 mt-4"></nav> <div class="flex-1"></div> <div class="px-3 pb-6 space-y-2 border-t border-white/10 pt-4"><a href="/settings" class="flex items-center p-3 rounded-xl hover:bg-light hover:text-darker transition-colors group"><div class="flex items-center justify-center min-w-8"><!></div> <!></a> <!> <button class="w-full flex items-center p-3 rounded-xl hover:bg-red-500 hover:text-white transition-colors group text-red-400"><div class="flex items-center justify-center min-w-8"><!></div> <!></button> <!></div></aside>');function To(e,t){Vt(t,!1);const n=()=>Ce(ae,"$isExpanded",o),[o,r]=Re();async function s(){await an("/login")}const i=[{icon:yo,label:"Home",href:"/home"},{icon:bo,label:"Dashboard",href:"/patients/dashboard"},{icon:Oo,label:"Patient Overview",href:"/patients/overview"},{icon:_o,label:"Patient Permissions",href:"/patients/permissions"},{icon:xo,label:"Patient Test Results",href:"/patients/test_results"},{icon:vo,label:"Calendar",href:"/calendar"},{icon:Bt,label:"Patient Management",href:"/settings/admin/patient"},{icon:Bt,label:"Doctor Management",href:"/settings/admin/doctor"},{icon:Bt,label:"Sys Admin",href:"/settings/admin/system"}];function a(){ae.update(b=>!b)}sn();var l=Lo(),c=z(l),f=z(c);{var u=b=>{var R=Ao();P(b,R)};Z(f,b=>{n()&&b(u)})}var m=H(f,2),d=z(m);{var g=b=>{po(b,{size:20})},h=b=>{wo(b,{size:20})};Z(d,b=>{n()?b(g):b(h,-1)})}B(m),B(c);var y=H(c,2);nn(y,5,()=>i,on,(b,R)=>{var $=Co(),L=q($),ht=z(L),Gt=z(ht);x(R).icon(Gt,{size:24}),B(ht);var Kt=H(ht,2);{var Mt=J=>{var mt=Ro(),Dt=z(mt,!0);B(mt),wt(()=>me(Dt,x(R).label)),P(J,mt)};Z(Kt,J=>{n()&&J(Mt)})}B(L);var $t=H(L,2);{var kt=J=>{ne(J,{placement:"right",class:"bg-dark px-4 py-2 text-white font-medium",arrow:!1,children:(mt,Dt)=>{Qt();var v=Zt();wt(()=>me(v,x(R).label)),P(mt,v)},$$slots:{default:!0}})};Z($t,J=>{n()||J(kt)})}wt(()=>tn(L,"href",x(R).href)),P(b,$)}),B(y);var w=H(y,4),_=z(w),O=z(_),A=z(O);Bt(A,{size:24}),B(O);var p=H(O,2);{var E=b=>{var R=So();P(b,R)};Z(p,b=>{n()&&b(E)})}B(_);var T=H(_,2);{var D=b=>{ne(b,{placement:"right",class:"bg-dark px-4 py-2 text-white font-medium",arrow:!1,children:(R,$)=>{Qt();var L=Zt("Settings");P(R,L)},$$slots:{default:!0}})};Z(T,b=>{n()||b(D)})}var M=H(T,2),F=z(M),st=z(F);Eo(st,{size:24}),B(F);var Y=H(F,2);{var at=b=>{var R=Po();P(b,R)};Z(Y,b=>{n()&&b(at)})}B(M);var N=H(M,2);{var j=b=>{ne(b,{placement:"right",class:" bg-red-600 px-4 py-2 text-white font-medium",arrow:!1,children:(R,$)=>{Qt();var L=Zt("Logout");P(R,L)},$$slots:{default:!0}})};Z(N,b=>{n()||b(j)})}B(w),B(l),wt(()=>{Wt(l,1,`fixed top-0 left-0 z-50 flex flex-col h-screen bg-darker text-white transition-all duration-300 ease-in-out ${n()?"w-64":"w-20"}`),Wt(m,1,`p-2 rounded-lg hover:bg-light hover:text-darker transition-colors ${n()?"ml-auto":"mx-auto"}`)}),ge("click",m,a),ge("click",M,s),P(e,l),jt(),r()}rn(["click"]);var Mo=K('<div class="flex min-h-screen w-full overflow-x-hidden"><!> <main><header class="w-full bg-cyan dark:bg-[--medi-cyan]/70  shadow-md"></header> <div class="p-6 overflow-x-auto"><!></div></main></div>');function Zo(e,t){const n=()=>Ce(ae,"$isExpanded",o),[o,r]=Re();var s=Mo(),i=z(s);To(i,{});var a=H(i,2),l=H(z(a),2),c=z(l);ce(c,()=>t.children),B(l),B(a),B(s),wt(()=>Wt(a,1,`flex-1 min-w-0 transition-all duration-300 ${n()?"ml-64":"ml-20"}`)),P(e,s),r()}export{Zo as component};
