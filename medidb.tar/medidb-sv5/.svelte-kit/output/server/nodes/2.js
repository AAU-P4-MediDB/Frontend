

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(external)/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.D2bomru_.js","_app/immutable/chunks/Bzak7iHL.js","_app/immutable/chunks/CB3untgv.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/BeB8NPMP.js","_app/immutable/chunks/Ca4tGx_X.js","_app/immutable/chunks/uaT9V7qS.js"];
export const stylesheets = ["_app/immutable/assets/app.wVPi8_Kx.css"];
export const fonts = [];
