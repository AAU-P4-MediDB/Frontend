

export const index = 10;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(internal)/patients/overview/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/10.BW_TdeB4.js","_app/immutable/chunks/Bzak7iHL.js","_app/immutable/chunks/CB3untgv.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/BeB8NPMP.js","_app/immutable/chunks/5pqwCMTs.js","_app/immutable/chunks/BSMSj-mh.js","_app/immutable/chunks/BIncqGdJ.js","_app/immutable/chunks/Dgvtnrtq.js","_app/immutable/chunks/CCHVBBkx.js","_app/immutable/chunks/CuUtCWQh.js","_app/immutable/chunks/Ca4tGx_X.js","_app/immutable/chunks/uaT9V7qS.js","_app/immutable/chunks/BJPHRiUJ.js","_app/immutable/chunks/DcnoHw8C.js","_app/immutable/chunks/U_z0ZYdG.js","_app/immutable/chunks/bPtIMHYa.js","_app/immutable/chunks/TPiffgTq.js"];
export const stylesheets = ["_app/immutable/assets/Tour.CD54FDqW.css"];
export const fonts = [];
