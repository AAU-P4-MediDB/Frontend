

export const index = 16;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(internal)/settings/admin/system/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/16.DB8de2-i.js","_app/immutable/chunks/Bzak7iHL.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/CB3untgv.js","_app/immutable/chunks/BeB8NPMP.js","_app/immutable/chunks/5pqwCMTs.js","_app/immutable/chunks/CsUrhNXK.js","_app/immutable/chunks/Dgvtnrtq.js","_app/immutable/chunks/Ca4tGx_X.js","_app/immutable/chunks/uaT9V7qS.js","_app/immutable/chunks/bPtIMHYa.js","_app/immutable/chunks/TPiffgTq.js","_app/immutable/chunks/llEsX-JL.js","_app/immutable/chunks/0NnI20nI.js","_app/immutable/chunks/D9HhWqGU.js","_app/immutable/chunks/ctqh9wgi.js","_app/immutable/chunks/BIncqGdJ.js","_app/immutable/chunks/CCHVBBkx.js"];
export const stylesheets = [];
export const fonts = [];
