

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.DQkK0aEO.js","_app/immutable/chunks/Bzak7iHL.js","_app/immutable/chunks/CB3untgv.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/BeB8NPMP.js","_app/immutable/chunks/Ca4tGx_X.js","_app/immutable/chunks/uaT9V7qS.js"];
export const stylesheets = [];
export const fonts = [];
