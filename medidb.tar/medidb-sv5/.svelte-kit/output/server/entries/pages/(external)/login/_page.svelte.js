import { a as attr_class, n as attr, e as escape_html } from "../../../../chunks/index.js";
import "@sveltejs/kit/internal";
import "../../../../chunks/exports.js";
import "../../../../chunks/utils2.js";
import "@sveltejs/kit/internal/server";
import "../../../../chunks/root.js";
import "../../../../chunks/state.svelte.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let emailValue = "";
    let passwordValue = "";
    let rememberMe = false;
    let emailError = false;
    let passwordError = false;
    let loading = false;
    $$renderer2.push(`<div class="scene svelte-9ah1qd"><div class="card svelte-9ah1qd"><div class="card-inner svelte-9ah1qd"><h3 class="svelte-9ah1qd">Sign in to your MediDB account</h3> <div${attr_class("field svelte-9ah1qd", void 0, { "has-error": emailError })}><label for="email" class="svelte-9ah1qd">Email</label> <input id="email" type="email" placeholder="name@company.com"${attr("value", emailValue)} class="svelte-9ah1qd"/> <span class="field-error svelte-9ah1qd">Please enter a valid email address.</span></div> <div${attr_class("field svelte-9ah1qd", void 0, { "has-error": passwordError })}><label for="pass" class="svelte-9ah1qd">Your password</label> <input id="pass" type="password" placeholder="••••••••"${attr("value", passwordValue)} class="svelte-9ah1qd"/> <span class="field-error svelte-9ah1qd">Password cannot be empty.</span></div> <div class="remember-row svelte-9ah1qd"><input type="checkbox" id="remember"${attr("checked", rememberMe, true)} class="svelte-9ah1qd"/> <label for="remember" class="svelte-9ah1qd">Remember me</label></div> <button class="login-btn svelte-9ah1qd"${attr("disabled", loading, true)}>${escape_html("Login")}</button></div></div></div>`);
  });
}
export {
  _page as default
};
