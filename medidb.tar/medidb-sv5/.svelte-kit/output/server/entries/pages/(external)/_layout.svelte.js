/* empty css                  */
function _layout($$renderer, $$props) {
  let { children } = $$props;
  $$renderer.push(`<div style="background-image: url('https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba4484ec8c29'); background-size: cover; background-repeat: no-repeat; background-position: center; height: 100vh; filter: brightness(0.8) blur(30px);"></div> `);
  children($$renderer);
  $$renderer.push(`<!---->`);
}
export {
  _layout as default
};
