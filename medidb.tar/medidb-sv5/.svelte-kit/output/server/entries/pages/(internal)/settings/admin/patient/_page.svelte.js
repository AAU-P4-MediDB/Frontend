import { m as ensure_array_like } from "../../../../../../chunks/index.js";
import "@sveltejs/kit/internal";
import "../../../../../../chunks/exports.js";
import "../../../../../../chunks/utils2.js";
import "@sveltejs/kit/internal/server";
import "../../../../../../chunks/root.js";
import "../../../../../../chunks/state.svelte.js";
import { G as GreyButton } from "../../../../../../chunks/GreyButton.js";
import { D as DoctorCard } from "../../../../../../chunks/DoctorCard.js";
function _page($$renderer) {
  const users = [
    {
      title: "Pirate",
      name: "Emma Nielsen",
      gender: "Female",
      age: "22",
      imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba15f58c562b"
    },
    {
      title: "Chef",
      name: "John Cena",
      gender: "Male",
      age: "45",
      imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2b06880c98"
    }
  ];
  $$renderer.push(`<div class="grid grid-cols-3 gap-4"><div class="..."><div class="h2">Patient Settings</div> <!--[-->`);
  const each_array = ensure_array_like(users);
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let user = each_array[$$index];
    DoctorCard($$renderer, { imageUrl: user.imageUrl, name: user.name });
  }
  $$renderer.push(`<!--]--></div> <div class="col-span-2 ..."><div class="grid grid-cols-4 gap-4"><div class="...">`);
  GreyButton($$renderer, {
    href: "/patients/dashboard",
    children: ($$renderer2) => {
      $$renderer2.push(`<!---->Patients`);
    }
  });
  $$renderer.push(`<!----></div> <div class="...">`);
  GreyButton($$renderer, {
    href: "/calendar",
    children: ($$renderer2) => {
      $$renderer2.push(`<!---->Calendar`);
    }
  });
  $$renderer.push(`<!----></div> <div class="...">`);
  GreyButton($$renderer, {
    href: "/login",
    children: ($$renderer2) => {
      $$renderer2.push(`<!---->Test results`);
    }
  });
  $$renderer.push(`<!----></div> <div class="...">`);
  GreyButton($$renderer, {
    href: "/login",
    children: ($$renderer2) => {
      $$renderer2.push(`<!---->Permissions`);
    }
  });
  $$renderer.push(`<!----></div></div></div></div>`);
}
export {
  _page as default
};
