import { q as run, g as getContext, a as attr_class, c as clsx, d as clsx$1, h as bind_props, i as derived, b as attributes, m as ensure_array_like } from "../../../../chunks/index.js";
import "@sveltejs/kit/internal";
import "../../../../chunks/exports.js";
import "../../../../chunks/utils2.js";
import "@sveltejs/kit/internal/server";
import "../../../../chunks/root.js";
import "../../../../chunks/state.svelte.js";
import { g as goto } from "../../../../chunks/client.js";
import { G as GreyButton } from "../../../../chunks/GreyButton.js";
import { C as CardOverlay, D as DefaultCard } from "../../../../chunks/DefaultCard.js";
import { I as ImageCard } from "../../../../chunks/ImageCard.js";
import { i as input } from "../../../../chunks/theme.js";
import { L as Label } from "../../../../chunks/Label.js";
import { w as warnThemeDeprecation, g as getTheme, a as getButtonGroupContext } from "../../../../chunks/themeUtils.js";
import { c as createDismissableContext, C as CloseButton } from "../../../../chunks/CloseButton.js";
function Input($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      children,
      left,
      right,
      value = void 0,
      elementRef = void 0,
      clearable = false,
      size,
      color = "default",
      class: className,
      classes,
      wrapperClass,
      leftClass,
      rightClass,
      divClass,
      clearableSvgClass,
      clearableColor = "none",
      clearableClass,
      clearableOnClick,
      data = [],
      maxSuggestions = 5,
      onSelect,
      comboClass,
      comboItemClass,
      onInput,
      onFocus,
      onBlur,
      onKeydown,
      oninput,
      onfocus,
      onblur,
      onkeydown,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    warnThemeDeprecation(
      "Input",
      run(() => ({
        wrapperClass,
        leftClass,
        rightClass,
        divClass,
        clearableSvgClass,
        clearableClass,
        comboClass
      }))
    );
    const styling = derived(() => classes ?? {
      left: leftClass,
      right: rightClass,
      div: divClass,
      svg: clearableSvgClass,
      close: clearableClass,
      combo: comboClass,
      comboItem: comboItemClass
    });
    const theme = derived(() => getTheme("input"));
    const isCombobox = derived(() => Array.isArray(data) && data.length > 0);
    let background = getContext("background");
    let group = derived(getButtonGroupContext);
    let isGroup = derived(() => !!group());
    let _size = derived(() => size || (group()?.size ? clampSize(group().size) : void 0) || "md");
    const _color = derived(() => color === "default" && background ? "tinted" : color);
    const $$d = derived(() => input({ size: _size(), color: _color(), grouped: isGroup() })), base = derived(() => $$d().base), inputCls = derived(() => $$d().input), leftCls = derived(() => $$d().left), rightCls = derived(() => $$d().right), close = derived(() => $$d().close);
    const clearAll = () => {
      if (elementRef) {
        const input2 = elementRef;
        input2.value = "";
        value = "";
        updateSuggestions();
        setTimeout(
          () => {
            input2.focus();
          },
          100
        );
      }
      if (clearableOnClick) clearableOnClick();
    };
    createDismissableContext(clearAll);
    let isFocused = false;
    function updateSuggestions() {
      if (!isCombobox() || !isFocused) {
        return;
      }
    }
    function inputContent($$renderer3, wrapped) {
      if (children) {
        $$renderer3.push("<!--[0-->");
        children($$renderer3, { ...restProps, class: inputCls()() });
        $$renderer3.push(`<!---->`);
      } else {
        $$renderer3.push("<!--[-1-->");
        $$renderer3.push(`<input${attributes(
          {
            ...restProps,
            value,
            class: clsx([
              wrapped || base()(),
              inputCls()({ class: clsx$1(theme()?.input, className) })
            ])
          },
          void 0,
          void 0,
          void 0,
          4
        )}/> `);
        if (value !== void 0 && value !== "" && clearable) {
          $$renderer3.push("<!--[0-->");
          CloseButton($$renderer3, {
            class: close()({ class: clsx$1(theme()?.close, styling().close) }),
            color: clearableColor,
            "aria-label": "Clear search value",
            svgClass: clsx$1(styling().svg)
          });
        } else {
          $$renderer3.push("<!--[-1-->");
        }
        $$renderer3.push(`<!--]-->`);
      }
      $$renderer3.push(`<!--]-->`);
    }
    if (clearable) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div tabindex="-1" class="sr-only"></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (isCombobox() || right || left || clearable) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div${attr_class(clsx(base()({ class: clsx$1(theme()?.base, styling().div) })))}>`);
      if (left) {
        $$renderer2.push("<!--[0-->");
        $$renderer2.push(`<div${attr_class(clsx(leftCls()({ class: clsx$1(theme()?.left, styling().left) })))}>`);
        left($$renderer2);
        $$renderer2.push(`<!----></div>`);
      } else {
        $$renderer2.push("<!--[-1-->");
      }
      $$renderer2.push(`<!--]--> `);
      inputContent($$renderer2, true);
      $$renderer2.push(`<!----> `);
      if (right) {
        $$renderer2.push("<!--[0-->");
        $$renderer2.push(`<div${attr_class(clsx(rightCls()({ class: clsx$1(theme()?.right, styling().right) })))}>`);
        right($$renderer2);
        $$renderer2.push(`<!----></div>`);
      } else {
        $$renderer2.push("<!--[-1-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (isCombobox() && isFocused) ;
      else {
        $$renderer2.push("<!--[-1-->");
      }
      $$renderer2.push(`<!--]--></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
      inputContent($$renderer2, false);
    }
    $$renderer2.push(`<!--]-->`);
    bind_props($$props, { value, elementRef });
  });
}
function clampSize(s) {
  return s && s === "xs" ? "sm" : s === "xl" ? "lg" : s;
}
function CyanButton($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { children } = $$props;
    $$renderer2.push(`<button class="h-10 w-full my-4 text-white font-bold bg-dark rounded-lg shadow-md hover:bg-light hover:text-darker duration-200 ease-in-out">`);
    children?.($$renderer2);
    $$renderer2.push(`<!----></button>`);
  });
}
function DefaultButton($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { href = "/", buttonAction = () => goto(), children } = $$props;
    $$renderer2.push(`<button class="h-10 w-full my-4 text-white font-bold bg-dark rounded-lg shadow-md hover:bg-darker hover:text-white duration-300 ease-in-out">`);
    children?.($$renderer2);
    $$renderer2.push(`<!----></button>`);
  });
}
function EmailCard($$renderer) {
  $$renderer.push(`<div class="mb-6">`);
  Label($$renderer, {
    for: "default-input",
    class: "mb-2 block dark:text-black",
    children: ($$renderer2) => {
      $$renderer2.push(`<!---->Email`);
    },
    $$slots: { default: true }
  });
  $$renderer.push(`<!----> `);
  Input($$renderer, { id: "default-input", placeholder: "Email" });
  $$renderer.push(`<!----> `);
  DefaultButton($$renderer, {
    children: ($$renderer2) => {
      $$renderer2.push(`<!---->Fetch doctor`);
    }
  });
  $$renderer.push(`<!----></div>`);
}
function _page($$renderer) {
  const patients = [
    {
      title: "Pirate",
      name: "Emma Nielsen",
      gender: "Female",
      age: "22",
      imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba15f58c562b"
    },
    {
      title: "Chef",
      name: "John Cena",
      gender: "Male",
      age: "45",
      imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2b06880c98"
    }
  ];
  const defaultCards = [
    {
      date: "Mar 2026",
      title: "EKG",
      description: "No heartrate detected",
      status: "red"
    },
    {
      date: "June 2026",
      title: "Ultrasound",
      description: "No baby detected",
      status: "red"
    },
    {
      date: "Aug 2026",
      title: "EKG",
      description: "Heartrate detected",
      status: "blue"
    }
  ];
  const fetchEmail = [{ title: "Fetch doctor", email: "doctor@aau.dk" }];
  $$renderer.push(`<div class="mx-auto"><div class="grid grid-cols-1 md:grid-cols-3 gap-4">`);
  GreyButton($$renderer, {
    href: "/login",
    children: ($$renderer2) => {
      $$renderer2.push(`<!---->Grey button`);
    }
  });
  $$renderer.push(`<!----> `);
  CyanButton($$renderer, {
    children: ($$renderer2) => {
      $$renderer2.push(`<!---->Cyan button`);
    }
  });
  $$renderer.push(`<!----> `);
  DefaultButton($$renderer, {
    href: "/login",
    children: ($$renderer2) => {
      $$renderer2.push(`<!---->Default button`);
    }
  });
  $$renderer.push(`<!----></div></div> <div class="px-20 max-w-[2000px] mx-auto"><div class="h-auto p-4"><div class="grid grid-cols-3 gap-4"><!--[-->`);
  const each_array = ensure_array_like(patients);
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let patient = each_array[$$index];
    ImageCard($$renderer, {
      title: patient.title,
      imageUrl: patient.imageUrl,
      name: patient.name,
      gender: patient.gender,
      age: patient.age
    });
  }
  $$renderer.push(`<!--]--></div></div></div> <div class="px-20 max-w-[2000px] mx-auto"><div class="h-auto p-4"><div class="grid grid-cols-3 gap-4">`);
  CardOverlay($$renderer, {
    children: ($$renderer2) => {
      $$renderer2.push(`<div class="my-3">Notification</div> <!--[-->`);
      const each_array_1 = ensure_array_like(defaultCards);
      for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
        let card = each_array_1[$$index_1];
        DefaultCard($$renderer2, {
          title: card.title,
          date: card.date,
          description: card.description,
          status: card.status
        });
      }
      $$renderer2.push(`<!--]-->`);
    }
  });
  $$renderer.push(`<!----> `);
  CardOverlay($$renderer, {
    children: ($$renderer2) => {
      $$renderer2.push(`<div class="my-3">Hello</div> <!--[-->`);
      const each_array_2 = ensure_array_like(defaultCards);
      for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
        let card = each_array_2[$$index_2];
        DefaultCard($$renderer2, {
          title: card.title,
          date: card.date,
          description: card.description,
          status: card.status
        });
      }
      $$renderer2.push(`<!--]-->`);
    }
  });
  $$renderer.push(`<!----> `);
  CardOverlay($$renderer, {
    children: ($$renderer2) => {
      $$renderer2.push(`<div class="my-3">Fetch doctor</div> <!--[-->`);
      const each_array_3 = ensure_array_like(fetchEmail);
      for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
        each_array_3[$$index_3];
        EmailCard($$renderer2);
      }
      $$renderer2.push(`<!--]-->`);
    }
  });
  $$renderer.push(`<!----></div></div></div>`);
}
export {
  _page as default
};
