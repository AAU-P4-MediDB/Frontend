import { q as run, a as attr_class, c as clsx, d as clsx$1, b as attributes, h as bind_props, i as derived, m as ensure_array_like } from "../../../../../chunks/index.js";
import { I as ImageCard } from "../../../../../chunks/ImageCard.js";
import { s as search } from "../../../../../chunks/theme.js";
import { c as createDismissableContext, C as CloseButton } from "../../../../../chunks/CloseButton.js";
import { w as warnThemeDeprecation, g as getTheme } from "../../../../../chunks/themeUtils.js";
function Search($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      children,
      inputClass,
      size,
      placeholder = "Search",
      value = void 0,
      elementRef = void 0,
      clearable = false,
      clearableSvgClass,
      clearableColor = "none",
      clearableClass,
      clearableOnClick,
      class: className,
      classes,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    warnThemeDeprecation("Search", run(() => ({ inputClass, clearableSvgClass, clearableClass })));
    const styling = derived(() => classes ?? {
      input: inputClass,
      svg: clearableSvgClass,
      close: clearableClass
    });
    const theme = derived(() => getTheme("search"));
    const $$d = derived(() => search({ size })), base = derived(() => $$d().base), content = derived(() => $$d().content), icon = derived(() => $$d().icon), close = derived(() => $$d().close), inputCls = derived(() => $$d().input), left = derived(() => $$d().left);
    const clearAll = () => {
      if (elementRef) {
        elementRef.value = "";
        value = void 0;
      }
      if (clearableOnClick) clearableOnClick();
    };
    createDismissableContext(clearAll);
    $$renderer2.push(`<div${attr_class(clsx(base()({ class: clsx$1(theme()?.base, className) })))}><div${attr_class(clsx(left()({ class: clsx$1(theme()?.left, classes?.left) })))}><svg${attr_class(clsx(icon()({ class: clsx$1(theme()?.icon, classes?.icon) })))} aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"></path></svg></div> <input${attributes(
      {
        type: "search",
        value,
        class: clsx(inputCls()({ class: clsx$1(theme()?.input, styling().input) })),
        placeholder,
        required: true,
        ...restProps
      },
      void 0,
      void 0,
      void 0,
      4
    )}/> `);
    if (children) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div${attr_class(clsx(content()({ class: clsx$1(theme()?.content, classes?.content) })))}>`);
      children($$renderer2);
      $$renderer2.push(`<!----></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (value !== void 0 && value !== "" && clearable) {
      $$renderer2.push("<!--[0-->");
      CloseButton($$renderer2, {
        class: close()({ class: clsx$1(theme()?.close, styling().close) }),
        color: clearableColor,
        "aria-label": "Clear search value",
        svgClass: clsx$1(styling().svg)
      });
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--></div>`);
    bind_props($$props, { value, elementRef });
  });
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let searchTerm = "";
    const patients = [
      {
        title: "Pirate",
        name: "Emma Nielsen",
        gender: "Female",
        age: "22",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba15f58c562b"
      },
      {
        title: "Chef",
        name: "John Cena",
        gender: "Male",
        age: "45",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2b06880c98"
      },
      {
        name: "Sophia Lee",
        gender: "Female",
        age: "45",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2bc07d8ed9"
      },
      {
        name: "Colby Durdan",
        gender: "Male",
        age: "54",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba3026bc4e44"
      },
      {
        name: "Liam Carter",
        gender: "Male",
        age: "54",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2c545a3381"
      },
      {
        name: "Sophia Nguyen",
        gender: "Female",
        age: "28",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2c853ba9ef"
      },
      {
        name: "Ethan Patel",
        gender: "Male",
        age: "29",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2ceafa1e19"
      },
      {
        name: "Olivia Martinez",
        gender: "Female",
        age: "35",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2d1e53c9bf"
      },
      {
        name: "Noah Kim",
        gender: "Male",
        age: "35",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba24b41ed4ea"
      },
      {
        name: "Ava Johnson",
        gender: "Female",
        age: "37",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2d8ead7b33"
      },
      {
        name: "Lucas Brown",
        gender: "Male",
        age: "40",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2ddaa65d3f"
      },
      {
        name: "Mia Rodriguez",
        gender: "Female",
        age: "26",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2ef58f784a"
      },
      {
        name: "Isabella Lee",
        gender: "Female",
        age: "27",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2e15515d35"
      },
      {
        name: "Sebastian Wilson",
        gender: "Male",
        age: "57",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2e502e45a7"
      },
      {
        name: "Charlotte Davis",
        gender: "Female",
        age: "32",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2e96549117"
      },
      {
        name: "Malte Jasonsen",
        gender: "Male",
        age: "54",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2f3ac31dad"
      }
    ];
    let filteredItems = derived(() => patients.filter((patient) => !searchTerm || patient.name.toLowerCase().includes(searchTerm.toLowerCase())));
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      Search($$renderer3, {
        size: "md",
        clearable: true,
        get value() {
          return searchTerm;
        },
        set value($$value) {
          searchTerm = $$value;
          $$settled = false;
        }
      });
      $$renderer3.push(`<!----> <hr class="border-gray-200 my-6"/> <div class="grid grid-cols-4 gap-4"><!--[-->`);
      const each_array = ensure_array_like(filteredItems().slice(0, 16));
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let patient = each_array[$$index];
        ImageCard($$renderer3, {
          title: patient.title,
          imageUrl: patient.imageUrl,
          name: patient.name,
          gender: patient.gender,
          age: patient.age
        });
      }
      $$renderer3.push(`<!--]--></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
export {
  _page as default
};
