function _page($$renderer) {
  $$renderer.push(`<div>Settings</div>`);
}
export {
  _page as default
};
