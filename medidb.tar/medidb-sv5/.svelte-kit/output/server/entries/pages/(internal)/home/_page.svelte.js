import { m as ensure_array_like } from "../../../../chunks/index.js";
import "../../../../chunks/theme.js";
import "@sveltejs/kit/internal";
import "../../../../chunks/exports.js";
import "../../../../chunks/utils2.js";
import "@sveltejs/kit/internal/server";
import "../../../../chunks/root.js";
import "../../../../chunks/state.svelte.js";
import { G as GreyButton } from "../../../../chunks/GreyButton.js";
import { C as CardOverlay, D as DefaultCard } from "../../../../chunks/DefaultCard.js";
import { D as DoctorCard } from "../../../../chunks/DoctorCard.js";
import { A as AppointmentsTimeline } from "../../../../chunks/AppointmentsTimeline.js";
import dayjs from "dayjs";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const appointments = [
      {
        id: 1,
        title: "Routine Checkup",
        date: dayjs().subtract(3, "day").format("YYYY-MM-DDTHH:mm:ss"),
        status: "completed",
        description: "Vitals normal. No concerns reported."
      },
      {
        id: 2,
        title: "Blood test results",
        date: dayjs().format("YYYY-MM-DDTHH:mm:ss"),
        status: "in-progress",
        description: "Waiting for lab results"
      },
      {
        id: 3,
        title: "Routine Checkup",
        date: dayjs().subtract(3, "day").format("YYYY-MM-DDTHH:mm:ss"),
        status: "completed",
        description: "Vitals normal. No concerns reported."
      },
      {
        id: 4,
        title: "Follow-up appointment",
        date: dayjs().subtract(1, "day").format("YYYY-MM-DDTHH:mm:ss"),
        status: "completed",
        description: "Follow-up appointment completed successfully."
      }
    ];
    const users = [
      {
        name: "Olivia Martinez",
        imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2d1e53c9bf"
      }
    ];
    const notifications = [
      {
        date: "Mar 2026",
        title: "EKG",
        description: "No heartrate detected",
        status: "red"
      },
      {
        date: "June 2026",
        title: "Ultrasound",
        description: "No baby detected",
        status: "red"
      },
      {
        date: "Aug 2026",
        title: "EKG",
        description: "Heartrate detected",
        status: "blue"
      }
    ];
    const permissionRequests = [
      {
        date: "Mar 2026",
        title: "Blood test lab results",
        description: "Vitals normal. No concerns reported",
        status: "red"
      }
    ];
    $$renderer2.push(`<div class="grid grid-cols-3 gap-4"><div class="..."><!--[-->`);
    const each_array = ensure_array_like(users);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let user = each_array[$$index];
      DoctorCard($$renderer2, { imageUrl: user.imageUrl, name: user.name });
    }
    $$renderer2.push(`<!--]--></div> <div class="col-span-2"><div class="grid grid-cols-4 gap-4"><div class="...">`);
    GreyButton($$renderer2, {
      href: "/patients/dashboard",
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->Patients`);
      }
    });
    $$renderer2.push(`<!----></div> <div class="...">`);
    GreyButton($$renderer2, {
      href: "/calendar",
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->Calendar`);
      }
    });
    $$renderer2.push(`<!----></div> <div class="...">`);
    GreyButton($$renderer2, {
      href: "/login",
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->Test results`);
      }
    });
    $$renderer2.push(`<!----></div> <div class="...">`);
    GreyButton($$renderer2, {
      href: "/login",
      children: ($$renderer3) => {
        $$renderer3.push(`<!---->Permissions`);
      }
    });
    $$renderer2.push(`<!----></div></div></div></div> <hr class="border-gray-200 my-6"/> <div class="grid grid-cols-3 grid-flow-col grid-rows-3 gap-4"><div class="row-span-2">`);
    CardOverlay($$renderer2, {
      children: ($$renderer3) => {
        $$renderer3.push(`<div>Notification</div> <!--[-->`);
        const each_array_1 = ensure_array_like(notifications);
        for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
          let notification = each_array_1[$$index_1];
          DefaultCard($$renderer3, {
            title: notification.title,
            date: notification.date,
            description: notification.description,
            status: notification.status
          });
        }
        $$renderer3.push(`<!--]-->`);
      }
    });
    $$renderer2.push(`<!----></div> <div class="...">`);
    CardOverlay($$renderer2, {
      children: ($$renderer3) => {
        $$renderer3.push(`<div>Permission requests</div> <!--[-->`);
        const each_array_2 = ensure_array_like(permissionRequests);
        for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
          let request = each_array_2[$$index_2];
          DefaultCard($$renderer3, {
            title: request.title,
            date: request.date,
            description: request.description,
            status: request.status
          });
        }
        $$renderer3.push(`<!--]-->`);
      }
    });
    $$renderer2.push(`<!----></div> <div class="row-span-3">`);
    CardOverlay($$renderer2, {
      children: ($$renderer3) => {
        AppointmentsTimeline($$renderer3, { appointments });
      }
    });
    $$renderer2.push(`<!----></div> <div class="row-span-3">`);
    CardOverlay($$renderer2, {
      children: ($$renderer3) => {
        $$renderer3.push(`<div class="my-3">Appointments</div> <!--[-->`);
        const each_array_3 = ensure_array_like(appointments);
        for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
          let appointment = each_array_3[$$index_3];
          DefaultCard($$renderer3, {
            title: appointment.title,
            date: appointment.date,
            description: appointment.description,
            status: appointment.status
          });
        }
        $$renderer3.push(`<!--]-->`);
      }
    });
    $$renderer2.push(`<!----></div></div>`);
  });
}
export {
  _page as default
};
