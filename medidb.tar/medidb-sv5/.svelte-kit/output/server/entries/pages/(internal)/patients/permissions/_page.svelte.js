import { q as run, b as attributes, c as clsx, d as clsx$1, a as attr_class, h as bind_props, i as derived, m as ensure_array_like } from "../../../../../chunks/index.js";
import { e as toggle } from "../../../../../chunks/theme.js";
import { C as Card } from "../../../../../chunks/Card.js";
import { L as Label } from "../../../../../chunks/Label.js";
import { w as warnThemeDeprecation, g as getTheme } from "../../../../../chunks/themeUtils.js";
import "@sveltejs/kit/internal";
import "../../../../../chunks/exports.js";
import "../../../../../chunks/utils2.js";
import "@sveltejs/kit/internal/server";
import "../../../../../chunks/root.js";
import "../../../../../chunks/state.svelte.js";
import { I as ImageCard } from "../../../../../chunks/ImageCard.js";
function Toggle($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      children,
      size = "default",
      value,
      checked = void 0,
      disabled,
      color = "primary",
      class: className,
      classes,
      inputClass,
      spanClass,
      offLabel,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    warnThemeDeprecation("Toggle", run(() => ({ inputClass, spanClass })));
    const styling = derived(() => classes ?? { input: inputClass, span: spanClass });
    const theme = derived(() => getTheme("toggle"));
    const $$d = derived(() => toggle({ color, checked, size, disabled, off_state_label: !!offLabel })), input = derived(() => $$d().input), label = derived(() => $$d().label), span = derived(() => $$d().span);
    Label($$renderer2, {
      class: label()({ class: clsx$1(theme()?.label, className) }),
      children: ($$renderer3) => {
        if (offLabel) {
          $$renderer3.push("<!--[0-->");
          offLabel($$renderer3);
          $$renderer3.push(`<!---->`);
        } else {
          $$renderer3.push("<!--[-1-->");
        }
        $$renderer3.push(`<!--]--> <input${attributes(
          {
            type: "checkbox",
            checked,
            value,
            ...restProps,
            disabled,
            class: clsx(input()({ class: clsx$1(theme()?.input, styling().input) }))
          },
          void 0,
          void 0,
          void 0,
          4
        )}/> <span${attr_class(clsx(span()({ class: clsx$1(theme()?.span, styling().span) })))}></span> `);
        if (children) {
          $$renderer3.push("<!--[0-->");
          children($$renderer3);
          $$renderer3.push(`<!---->`);
        } else {
          $$renderer3.push("<!--[-1-->");
        }
        $$renderer3.push(`<!--]-->`);
      },
      $$slots: { default: true }
    });
    bind_props($$props, { checked });
  });
}
function _page($$renderer) {
  const patients = [
    {
      title: "Chef",
      name: "John Cena",
      gender: "Male",
      age: "45",
      imageUrl: "https://pp.voxvoltera.com/assets/by-file-media-id/78742b37-89de-81f6-8007-ba2b06880c98"
    }
  ];
  $$renderer.push(`<div class="grid"><div><!--[-->`);
  const each_array = ensure_array_like(patients);
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let patient = each_array[$$index];
    ImageCard($$renderer, {
      title: patient.title,
      imageUrl: patient.imageUrl,
      name: patient.name,
      gender: patient.gender,
      age: patient.age
    });
  }
  $$renderer.push(`<!--]--></div> <div><div class="grid grid-cols-4 m-4 px-20"><div>`);
  Card($$renderer, {
    href: "/cards",
    class: "p-4 sm:p-6 md:p-8",
    children: ($$renderer2) => {
      $$renderer2.push(`<h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Dr. Elias Thornbridge</h5> <p class="leading-tight font-normal text-gray-700 dark:text-gray-400">Full read access</p>`);
    },
    $$slots: { default: true }
  });
  $$renderer.push(`<!----> `);
  Card($$renderer, {
    href: "/cards",
    class: "p-4 sm:p-6 md:p-8",
    children: ($$renderer2) => {
      $$renderer2.push(`<h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Dr. Marissa Vale</h5> <p class="leading-tight font-normal text-gray-700 dark:text-gray-400">Read/write presciptions</p>`);
    },
    $$slots: { default: true }
  });
  $$renderer.push(`<!----> `);
  Card($$renderer, {
    href: "/cards",
    class: "p-4 sm:p-6 md:p-8",
    children: ($$renderer2) => {
      $$renderer2.push(`<h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Dr. Quentin Harlow</h5> <p class="leading-tight font-normal text-gray-700 dark:text-gray-400">Read diagnosis, anonymous</p>`);
    },
    $$slots: { default: true }
  });
  $$renderer.push(`<!----> `);
  Card($$renderer, {
    href: "/cards",
    class: "p-4 sm:p-6 md:p-8",
    children: ($$renderer2) => {
      $$renderer2.push(`<h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Dr. Lila Ravenscroft</h5> <p class="leading-tight font-normal text-gray-700 dark:text-gray-400">Read/write blood lab</p>`);
    },
    $$slots: { default: true }
  });
  $$renderer.push(`<!----></div> <div class="flex col-start-2 col-span-3 justify-start items-start mt-4">`);
  Card($$renderer, {
    class: "w-full p-4 sm:p-6 md:p-8 flex justify-center items-center",
    children: ($$renderer2) => {
      $$renderer2.push(`<div class="grid grid-cols-2 gap-y-6 gap-x-6 w-full max-w-none">`);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Write all`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Read all`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Write prescriptions`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Read prescriptions`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Write journal`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Read journal`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Write vitals`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Read vitals`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Write diagnosis`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Read diagnosis`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Write appointments`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Read appointments`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Write person info`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Read person info`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Write lab results`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----> `);
      Toggle($$renderer2, {
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Read lab results`);
        },
        $$slots: { default: true }
      });
      $$renderer2.push(`<!----></div>`);
    },
    $$slots: { default: true }
  });
  $$renderer.push(`<!----></div></div></div></div>`);
}
export {
  _page as default
};
