import { p as fallback, k as slot, h as bind_props, j as sanitize_props, r as rest_props, n as attr, m as ensure_array_like, f as spread_props } from "../../../../chunks/index.js";
import { createCalendar, createViewMonthGrid, createViewWeek, createViewDay } from "@schedule-x/calendar";
import "temporal-polyfill/global";
const randomStringId = () => "s" + Math.random().toString(36).substring(2, 11);
function Portal($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let target = fallback($$props["target"], "body");
    $$renderer2.push(`<div style="height: 100%; width: 100%" hidden=""><!--[-->`);
    slot($$renderer2, $$props, "default", {});
    $$renderer2.push(`<!--]--></div>`);
    bind_props($$props, { target });
  });
}
function Schedule_x_calendar($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  rest_props($$sanitized_props, ["calendarApp"]);
  $$renderer.component(($$renderer2) => {
    let wrapperId;
    let calendarApp = $$props["calendarApp"];
    let customComponentsMeta = [];
    wrapperId = randomStringId();
    $$renderer2.push(`<div><div class="sx-svelte-calendar-wrapper"${attr("id", wrapperId)}></div> <!--[-->`);
    const each_array = ensure_array_like(customComponentsMeta);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let customComponent = each_array[$$index];
      if (customComponent.Component) {
        $$renderer2.push("<!--[0-->");
        Portal($$renderer2, {
          target: customComponent.wrapperElement,
          children: ($$renderer3) => {
            if (customComponent.Component) {
              $$renderer3.push("<!--[-->");
              customComponent.Component($$renderer3, spread_props([customComponent.props]));
              $$renderer3.push("<!--]-->");
            } else {
              $$renderer3.push("<!--[!-->");
              $$renderer3.push("<!--]-->");
            }
          },
          $$slots: { default: true }
        });
      } else {
        $$renderer2.push("<!--[-1-->");
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]--></div>`);
    bind_props($$props, { calendarApp });
  });
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const calendarApp = createCalendar({
      views: [createViewMonthGrid(), createViewWeek(), createViewDay()],
      events: [
        {
          id: "1",
          title: "Routine Checkup — Emma Nielsen",
          start: Temporal.PlainDate.from("2026-03-29"),
          end: Temporal.PlainDate.from("2026-03-29")
        },
        {
          id: "2",
          title: "Blood Test Review — John Cena",
          start: Temporal.PlainDate.from("2026-04-02"),
          end: Temporal.PlainDate.from("2026-04-02")
        },
        {
          id: "3",
          title: "Diabetic Check-up — Emma Nielsen",
          start: Temporal.PlainDate.from("2026-04-28"),
          end: Temporal.PlainDate.from("2026-04-28")
        }
      ]
    });
    $$renderer2.push(`<div class="p-4">`);
    Schedule_x_calendar($$renderer2, { calendarApp });
    $$renderer2.push(`<!----></div>`);
  });
}
export {
  _page as default
};
