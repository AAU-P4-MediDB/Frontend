export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.xg2tkSOY.js",app:"_app/immutable/entry/app.Cz42W0oS.js",imports:["_app/immutable/entry/start.xg2tkSOY.js","_app/immutable/chunks/llEsX-JL.js","_app/immutable/chunks/CB3untgv.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/TPiffgTq.js","_app/immutable/chunks/0NnI20nI.js","_app/immutable/chunks/D9HhWqGU.js","_app/immutable/entry/app.Cz42W0oS.js","_app/immutable/chunks/CB3untgv.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/BIncqGdJ.js","_app/immutable/chunks/Dgvtnrtq.js","_app/immutable/chunks/BeB8NPMP.js","_app/immutable/chunks/Bzak7iHL.js","_app/immutable/chunks/D9HhWqGU.js","_app/immutable/chunks/BJPHRiUJ.js","_app/immutable/chunks/uaT9V7qS.js","_app/immutable/chunks/BA8ZTpD-.js","_app/immutable/chunks/U_z0ZYdG.js","_app/immutable/chunks/bPtIMHYa.js","_app/immutable/chunks/TPiffgTq.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js')),
			__memo(() => import('./nodes/6.js')),
			__memo(() => import('./nodes/7.js')),
			__memo(() => import('./nodes/8.js')),
			__memo(() => import('./nodes/9.js')),
			__memo(() => import('./nodes/10.js')),
			__memo(() => import('./nodes/11.js')),
			__memo(() => import('./nodes/12.js')),
			__memo(() => import('./nodes/13.js')),
			__memo(() => import('./nodes/14.js')),
			__memo(() => import('./nodes/15.js')),
			__memo(() => import('./nodes/16.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/(internal)/calendar",
				pattern: /^\/calendar\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/(internal)/componentExamples",
				pattern: /^\/componentExamples\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/(internal)/home",
				pattern: /^\/home\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/(external)/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/(internal)/patients/dashboard",
				pattern: /^\/patients\/dashboard\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/(internal)/patients/overview",
				pattern: /^\/patients\/overview\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 10 },
				endpoint: null
			},
			{
				id: "/(internal)/patients/permissions",
				pattern: /^\/patients\/permissions\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 11 },
				endpoint: null
			},
			{
				id: "/(internal)/patients/test_results",
				pattern: /^\/patients\/test_results\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/(internal)/settings",
				pattern: /^\/settings\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 13 },
				endpoint: null
			},
			{
				id: "/(internal)/settings/admin/doctor",
				pattern: /^\/settings\/admin\/doctor\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/(internal)/settings/admin/patient",
				pattern: /^\/settings\/admin\/patient\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 15 },
				endpoint: null
			},
			{
				id: "/(internal)/settings/admin/system",
				pattern: /^\/settings\/admin\/system\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 16 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
