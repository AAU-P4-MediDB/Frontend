import { n as attr, e as escape_html, s as stringify } from "./index.js";
function ImageCard($$renderer, $$props) {
  let { title, imageUrl, name, gender, age } = $$props;
  $$renderer.push(`<div class="flex my-1 items-center gap-4 rounded-xl bg-white p-4 shadow-md"><img class="aspect-square object-cover size-12 rounded-full"${attr("src", imageUrl)}${attr("alt", `Avatar for ${stringify(title)}`)}/> <div><div class="text-m font-bold">${escape_html(name)}</div> <div class="text-sm font-light">${escape_html(gender)} • ${escape_html(age)} yrs</div></div></div>`);
}
export {
  ImageCard as I
};
