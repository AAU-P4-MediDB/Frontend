import { b as attributes, c as clsx, d as clsx$1, q as run, i as derived, a as attr_class, n as attr } from "./index.js";
import { w as warnThemeDeprecation, g as getTheme } from "./themeUtils.js";
import { f as card } from "./theme.js";
function Card($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      children,
      color = "gray",
      horizontal = false,
      shadow = "md",
      reverse = false,
      img,
      size = "sm",
      class: className,
      classes,
      imgClass,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    warnThemeDeprecation("Card", run(() => ({ imgClass })));
    const styling = derived(() => classes ?? { image: imgClass });
    const theme = derived(() => getTheme("card"));
    const $$d = derived(() => card({
      size,
      color,
      shadow,
      horizontal,
      reverse,
      href: !!restProps.href
    })), base = derived(() => $$d().base), image = derived(() => $$d().image);
    function childSlot($$renderer3) {
      if (img) {
        $$renderer3.push("<!--[0-->");
        $$renderer3.push(`<img${attr_class(clsx(image()({ class: clsx$1(theme()?.image, styling().image) })))}${attr("src", img)} alt="" loading="lazy" onerror="this.__e=event"/> `);
        children?.($$renderer3);
        $$renderer3.push(`<!---->`);
      } else {
        $$renderer3.push("<!--[-1-->");
        children?.($$renderer3);
        $$renderer3.push(`<!---->`);
      }
      $$renderer3.push(`<!--]-->`);
    }
    if (restProps.href === void 0) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div${attributes({
        ...restProps,
        class: clsx(base()({ class: clsx$1(theme()?.base, className) }))
      })}>`);
      childSlot($$renderer2);
      $$renderer2.push(`<!----></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
      $$renderer2.push(`<a${attributes({
        ...restProps,
        class: clsx(base()({ class: clsx$1(theme()?.base, className) }))
      })}>`);
      childSlot($$renderer2);
      $$renderer2.push(`<!----></a>`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
export {
  Card as C
};
