import { t as setContext, b as attributes, c as clsx, i as derived, d as clsx$1, q as run, g as getContext, a as attr_class, n as attr, e as escape_html, j as sanitize_props, f as spread_props, k as slot, m as ensure_array_like, s as stringify } from "./index.js";
import { a as timeline, b as timelineItem, c as twMerge } from "./theme.js";
import { g as getTheme, w as warnThemeDeprecation } from "./themeUtils.js";
import { I as Icon } from "./Icon.js";
function Timeline($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      children,
      order = "default",
      class: className,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const theme = derived(() => getTheme("timeline"));
    setContext("order", order);
    const olCls = derived(() => timeline({ order, class: clsx$1(theme(), className) }));
    $$renderer2.push(`<ol${attributes({ ...restProps, class: clsx(olCls()) })}>`);
    children($$renderer2);
    $$renderer2.push(`<!----></ol>`);
  });
}
function TimelineItem($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      children,
      orientationSlot,
      title,
      date,
      dateFormat = "month-year",
      color = "primary",
      isLast = false,
      svgClass,
      liClass,
      defaultDivClass,
      divClass,
      timeClass,
      h3Class,
      connectorClass,
      datePrefix,
      class: className,
      classes,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    warnThemeDeprecation(
      "TimelineItem",
      run(() => ({
        svgClass,
        liClass,
        divClass,
        timeClass,
        h3Class,
        connectorClass
      }))
    );
    const styling = derived(() => ({
      svg: svgClass,
      div: divClass,
      time: timeClass,
      h3: h3Class,
      connector: connectorClass
    }));
    const theme = derived(() => getTheme("timelineItem"));
    let order = getContext("order");
    const $$d = derived(() => timelineItem({ order, color, isLast })), base = derived(() => $$d().base), div = derived(() => $$d().div), defaultDiv = derived(() => $$d().defaultDiv), time = derived(() => $$d().time), h3 = derived(() => $$d().h3), svg = derived(() => $$d().svg), connector = derived(() => $$d().connector);
    const defaultDivCls = derived(() => defaultDivClass ? defaultDivClass : defaultDiv()());
    function formatDisplayDate(dateStr, format) {
      const date2 = new Date(dateStr);
      if (isNaN(date2.getTime())) return dateStr;
      switch (format) {
        case "year":
          return date2.toLocaleDateString(void 0, { year: "numeric" });
        case "month-year":
          return date2.toLocaleDateString(void 0, { month: "long", year: "numeric" });
        case "full-date":
          return date2.toLocaleDateString(void 0, { day: "numeric", month: "long", year: "numeric" });
        default:
          return date2.toLocaleDateString(void 0, { month: "long", year: "numeric" });
      }
    }
    $$renderer2.push(`<li${attributes({
      ...restProps,
      class: clsx(base()({ class: clsx$1(theme()?.base, className ?? liClass) }))
    })}>`);
    if (!isLast && (order === "vertical" || order === "activity")) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<div${attr_class(clsx(connector()({ class: clsx$1(theme()?.connector, styling().connector) })))} aria-hidden="true"></div>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (order !== "default") {
      $$renderer2.push("<!--[0-->");
      if (orientationSlot && (order === "vertical" || order === "horizontal")) {
        $$renderer2.push("<!--[0-->");
        orientationSlot($$renderer2);
        $$renderer2.push(`<!---->`);
      } else {
        $$renderer2.push("<!--[-1-->");
        $$renderer2.push(`<div${attr_class(clsx(div()({ class: clsx$1(theme()?.div, styling().div) })))}><svg aria-hidden="true"${attr_class(clsx(svg()({ class: clsx$1(theme()?.svg, styling().svg) })))} fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path></svg></div>`);
      }
      $$renderer2.push(`<!--]-->`);
    } else if (date) {
      $$renderer2.push("<!--[1-->");
      $$renderer2.push(`<div${attr_class(clsx(defaultDivCls()))} aria-hidden="true"></div> <time${attr("datetime", date)}${attr_class(clsx(time()({ class: clsx$1(theme()?.time, styling().time) })))}>${escape_html(datePrefix)}
      ${escape_html(formatDisplayDate(date, dateFormat))}</time>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (title) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<h3${attr_class(clsx(h3()({ class: clsx$1(theme()?.h3, styling().h3) })))}>${escape_html(title)}</h3>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    if (order !== "default") {
      $$renderer2.push("<!--[0-->");
      if (date) {
        $$renderer2.push("<!--[0-->");
        $$renderer2.push(`<time${attr("datetime", date)}${attr_class(clsx(time()({ class: clsx$1(theme()?.time, styling().time) })))}>${escape_html(datePrefix)}
        ${escape_html(formatDisplayDate(date, dateFormat))}</time>`);
      } else {
        $$renderer2.push("<!--[-1-->");
      }
      $$renderer2.push(`<!--]-->`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--> `);
    children($$renderer2);
    $$renderer2.push(`<!----></li>`);
  });
}
function Syringe($$renderer, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v1.0.1 - ISC
   *
   * ISC License
   *
   * Copyright (c) 2026 Lucide Icons and Contributors
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   * ---
   *
   * The following Lucide icons are derived from the Feather project:
   *
   * airplay, alert-circle, alert-octagon, alert-triangle, aperture, arrow-down-circle, arrow-down-left, arrow-down-right, arrow-down, arrow-left-circle, arrow-left, arrow-right-circle, arrow-right, arrow-up-circle, arrow-up-left, arrow-up-right, arrow-up, at-sign, calendar, cast, check, chevron-down, chevron-left, chevron-right, chevron-up, chevrons-down, chevrons-left, chevrons-right, chevrons-up, circle, clipboard, clock, code, columns, command, compass, corner-down-left, corner-down-right, corner-left-down, corner-left-up, corner-right-down, corner-right-up, corner-up-left, corner-up-right, crosshair, database, divide-circle, divide-square, dollar-sign, download, external-link, feather, frown, hash, headphones, help-circle, info, italic, key, layout, life-buoy, link-2, link, loader, lock, log-in, log-out, maximize, meh, minimize, minimize-2, minus-circle, minus-square, minus, monitor, moon, more-horizontal, more-vertical, move, music, navigation-2, navigation, octagon, pause-circle, percent, plus-circle, plus-square, plus, power, radio, rss, search, server, share, shopping-bag, sidebar, smartphone, smile, square, table-2, tablet, target, terminal, trash-2, trash, triangle, tv, type, upload, x-circle, x-octagon, x-square, x, zoom-in, zoom-out
   *
   * The MIT License (MIT) (for the icons listed above)
   *
   * Copyright (c) 2013-present Cole Bemis
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "m18 2 4 4" }],
    ["path", { "d": "m17 7 3-3" }],
    [
      "path",
      {
        "d": "M19 9 8.7 19.3c-1 1-2.5 1-3.4 0l-.6-.6c-1-1-1-2.5 0-3.4L15 5"
      }
    ],
    ["path", { "d": "m9 11 4 4" }],
    ["path", { "d": "m5 19-3 3" }],
    ["path", { "d": "m14 4 6 6" }]
  ];
  Icon($$renderer, spread_props([
    { name: "syringe" },
    $$sanitized_props,
    {
      /**
       * @component @name Syringe
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTggMiA0IDQiIC8+CiAgPHBhdGggZD0ibTE3IDcgMy0zIiAvPgogIDxwYXRoIGQ9Ik0xOSA5IDguNyAxOS4zYy0xIDEtMi41IDEtMy40IDBsLS42LS42Yy0xLTEtMS0yLjUgMC0zLjRMMTUgNSIgLz4KICA8cGF0aCBkPSJtOSAxMSA0IDQiIC8+CiAgPHBhdGggZD0ibTUgMTktMyAzIiAvPgogIDxwYXRoIGQ9Im0xNCA0IDYgNiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/syringe
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$renderer2) => {
        $$renderer2.push(`<!--[-->`);
        slot($$renderer2, $$props, "default", {});
        $$renderer2.push(`<!--]-->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function cn(...inputs) {
  return twMerge(clsx$1(inputs));
}
function CalendarMonthSolid($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const ctx = getContext("iconCtx") ?? {};
    const sizes = {
      xs: "w-3 h-3",
      sm: "w-4 h-4",
      md: "w-5 h-5",
      lg: "w-6 h-6",
      xl: "w-8 h-8"
    };
    let {
      size = ctx.size || "md",
      color = ctx.color || "currentColor",
      title,
      desc,
      class: className,
      ariaLabel,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let ariaDescribedby = `${title?.id || ""} ${desc?.id || ""}`.trim();
    const hasDescription = !!(title?.id || desc?.id);
    const isLabeled = !!ariaLabel || hasDescription;
    $$renderer2.push(`<svg${attributes(
      {
        xmlns: "http://www.w3.org/2000/svg",
        fill: color,
        ...restProps,
        class: clsx(cn("shrink-0", sizes[size], className)),
        viewBox: "0 0 24 24",
        "aria-label": ariaLabel,
        "aria-describedby": hasDescription ? ariaDescribedby : void 0,
        "aria-hidden": !isLabeled
      },
      void 0,
      void 0,
      void 0,
      3
    )}>`);
    if (title?.id && title.title) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<title${attr("id", title.id)}>${escape_html(title.title)}</title>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]-->`);
    if (desc?.id && desc.desc) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<desc${attr("id", desc.id)}>${escape_html(desc.desc)}</desc>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--><path fill-rule="evenodd" d="M5 5a1 1 0 0 0 1-1 1 1 0 1 1 2 0 1 1 0 0 0 1 1h1a1 1 0 0 0 1-1 1 1 0 1 1 2 0 1 1 0 0 0 1 1h1a1 1 0 0 0 1-1 1 1 0 1 1 2 0 1 1 0 0 0 1 1 2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a2 2 0 0 1 2-2ZM3 19v-7a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Zm6.01-6a1 1 0 1 0-2 0 1 1 0 0 0 2 0Zm2 0a1 1 0 1 1 2 0 1 1 0 0 1-2 0Zm6 0a1 1 0 1 0-2 0 1 1 0 0 0 2 0Zm-10 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0Zm6 0a1 1 0 1 0-2 0 1 1 0 0 0 2 0Zm2 0a1 1 0 1 1 2 0 1 1 0 0 1-2 0Z" clip-rule="evenodd"></path></svg>`);
  });
}
function CalendarPlusSolid($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const ctx = getContext("iconCtx") ?? {};
    const sizes = {
      xs: "w-3 h-3",
      sm: "w-4 h-4",
      md: "w-5 h-5",
      lg: "w-6 h-6",
      xl: "w-8 h-8"
    };
    let {
      size = ctx.size || "md",
      color = ctx.color || "currentColor",
      title,
      desc,
      class: className,
      ariaLabel,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let ariaDescribedby = `${title?.id || ""} ${desc?.id || ""}`.trim();
    const hasDescription = !!(title?.id || desc?.id);
    const isLabeled = !!ariaLabel || hasDescription;
    $$renderer2.push(`<svg${attributes(
      {
        xmlns: "http://www.w3.org/2000/svg",
        fill: color,
        ...restProps,
        class: clsx(cn("shrink-0", sizes[size], className)),
        viewBox: "0 0 24 24",
        "aria-label": ariaLabel,
        "aria-describedby": hasDescription ? ariaDescribedby : void 0,
        "aria-hidden": !isLabeled
      },
      void 0,
      void 0,
      void 0,
      3
    )}>`);
    if (title?.id && title.title) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<title${attr("id", title.id)}>${escape_html(title.title)}</title>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]-->`);
    if (desc?.id && desc.desc) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<desc${attr("id", desc.id)}>${escape_html(desc.desc)}</desc>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--><path fill-rule="evenodd" d="M18 5.05h1a2 2 0 0 1 2 2v2H3v-2a2 2 0 0 1 2-2h1v-1a1 1 0 1 1 2 0v1h3v-1a1 1 0 1 1 2 0v1h3v-1a1 1 0 1 1 2 0v1Zm-15 6v8a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-8H3ZM11 18a1 1 0 1 0 2 0v-1h1a1 1 0 1 0 0-2h-1v-1a1 1 0 1 0-2 0v1h-1a1 1 0 1 0 0 2h1v1Z" clip-rule="evenodd"></path></svg>`);
  });
}
function CalendarWeekSolid($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const ctx = getContext("iconCtx") ?? {};
    const sizes = {
      xs: "w-3 h-3",
      sm: "w-4 h-4",
      md: "w-5 h-5",
      lg: "w-6 h-6",
      xl: "w-8 h-8"
    };
    let {
      size = ctx.size || "md",
      color = ctx.color || "currentColor",
      title,
      desc,
      class: className,
      ariaLabel,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let ariaDescribedby = `${title?.id || ""} ${desc?.id || ""}`.trim();
    const hasDescription = !!(title?.id || desc?.id);
    const isLabeled = !!ariaLabel || hasDescription;
    $$renderer2.push(`<svg${attributes(
      {
        xmlns: "http://www.w3.org/2000/svg",
        fill: color,
        ...restProps,
        class: clsx(cn("shrink-0", sizes[size], className)),
        viewBox: "0 0 24 24",
        "aria-label": ariaLabel,
        "aria-describedby": hasDescription ? ariaDescribedby : void 0,
        "aria-hidden": !isLabeled
      },
      void 0,
      void 0,
      void 0,
      3
    )}>`);
    if (title?.id && title.title) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<title${attr("id", title.id)}>${escape_html(title.title)}</title>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]-->`);
    if (desc?.id && desc.desc) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<desc${attr("id", desc.id)}>${escape_html(desc.desc)}</desc>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--><path fill-rule="evenodd" d="M6 5V4a1 1 0 1 1 2 0v1h3V4a1 1 0 1 1 2 0v1h3V4a1 1 0 1 1 2 0v1h1a2 2 0 0 1 2 2v2H3V7a2 2 0 0 1 2-2h1ZM3 19v-8h18v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Zm5-6a1 1 0 1 0 0 2h8a1 1 0 1 0 0-2H8Z" clip-rule="evenodd"></path></svg>`);
  });
}
function CheckCircleSolid($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const ctx = getContext("iconCtx") ?? {};
    const sizes = {
      xs: "w-3 h-3",
      sm: "w-4 h-4",
      md: "w-5 h-5",
      lg: "w-6 h-6",
      xl: "w-8 h-8"
    };
    let {
      size = ctx.size || "md",
      color = ctx.color || "currentColor",
      title,
      desc,
      class: className,
      ariaLabel,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let ariaDescribedby = `${title?.id || ""} ${desc?.id || ""}`.trim();
    const hasDescription = !!(title?.id || desc?.id);
    const isLabeled = !!ariaLabel || hasDescription;
    $$renderer2.push(`<svg${attributes(
      {
        xmlns: "http://www.w3.org/2000/svg",
        fill: color,
        ...restProps,
        class: clsx(cn("shrink-0", sizes[size], className)),
        viewBox: "0 0 24 24",
        "aria-label": ariaLabel,
        "aria-describedby": hasDescription ? ariaDescribedby : void 0,
        "aria-hidden": !isLabeled
      },
      void 0,
      void 0,
      void 0,
      3
    )}>`);
    if (title?.id && title.title) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<title${attr("id", title.id)}>${escape_html(title.title)}</title>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]-->`);
    if (desc?.id && desc.desc) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<desc${attr("id", desc.id)}>${escape_html(desc.desc)}</desc>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--><path fill-rule="evenodd" d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm13.707-1.293a1 1 0 0 0-1.414-1.414L11 12.586l-1.793-1.793a1 1 0 0 0-1.414 1.414l2.5 2.5a1 1 0 0 0 1.414 0l4-4Z" clip-rule="evenodd"></path></svg>`);
  });
}
function ClockSolid($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const ctx = getContext("iconCtx") ?? {};
    const sizes = {
      xs: "w-3 h-3",
      sm: "w-4 h-4",
      md: "w-5 h-5",
      lg: "w-6 h-6",
      xl: "w-8 h-8"
    };
    let {
      size = ctx.size || "md",
      color = ctx.color || "currentColor",
      title,
      desc,
      class: className,
      ariaLabel,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let ariaDescribedby = `${title?.id || ""} ${desc?.id || ""}`.trim();
    const hasDescription = !!(title?.id || desc?.id);
    const isLabeled = !!ariaLabel || hasDescription;
    $$renderer2.push(`<svg${attributes(
      {
        xmlns: "http://www.w3.org/2000/svg",
        fill: color,
        ...restProps,
        class: clsx(cn("shrink-0", sizes[size], className)),
        viewBox: "0 0 24 24",
        "aria-label": ariaLabel,
        "aria-describedby": hasDescription ? ariaDescribedby : void 0,
        "aria-hidden": !isLabeled
      },
      void 0,
      void 0,
      void 0,
      3
    )}>`);
    if (title?.id && title.title) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<title${attr("id", title.id)}>${escape_html(title.title)}</title>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]-->`);
    if (desc?.id && desc.desc) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<desc${attr("id", desc.id)}>${escape_html(desc.desc)}</desc>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--><path fill-rule="evenodd" d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm11-4a1 1 0 1 0-2 0v4a1 1 0 0 0 .293.707l3 3a1 1 0 0 0 1.414-1.414L13 11.586V8Z" clip-rule="evenodd"></path></svg>`);
  });
}
function MessagesSolid($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const ctx = getContext("iconCtx") ?? {};
    const sizes = {
      xs: "w-3 h-3",
      sm: "w-4 h-4",
      md: "w-5 h-5",
      lg: "w-6 h-6",
      xl: "w-8 h-8"
    };
    let {
      size = ctx.size || "md",
      color = ctx.color || "currentColor",
      title,
      desc,
      class: className,
      ariaLabel,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    let ariaDescribedby = `${title?.id || ""} ${desc?.id || ""}`.trim();
    const hasDescription = !!(title?.id || desc?.id);
    const isLabeled = !!ariaLabel || hasDescription;
    $$renderer2.push(`<svg${attributes(
      {
        xmlns: "http://www.w3.org/2000/svg",
        fill: color,
        ...restProps,
        class: clsx(cn("shrink-0", sizes[size], className)),
        viewBox: "0 0 24 24",
        "aria-label": ariaLabel,
        "aria-describedby": hasDescription ? ariaDescribedby : void 0,
        "aria-hidden": !isLabeled
      },
      void 0,
      void 0,
      void 0,
      3
    )}>`);
    if (title?.id && title.title) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<title${attr("id", title.id)}>${escape_html(title.title)}</title>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]-->`);
    if (desc?.id && desc.desc) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<desc${attr("id", desc.id)}>${escape_html(desc.desc)}</desc>`);
    } else {
      $$renderer2.push("<!--[-1-->");
    }
    $$renderer2.push(`<!--]--><path fill-rule="evenodd" d="M4 3a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h1v2a1 1 0 0 0 1.707.707L9.414 13H15a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1H4Z" clip-rule="evenodd"></path><path fill-rule="evenodd" d="M8.023 17.215c.033-.03.066-.062.098-.094L10.243 15H15a3 3 0 0 0 3-3V8h2a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1h-1v2a1 1 0 0 1-1.707.707L14.586 18H9a1 1 0 0 1-.977-.785Z" clip-rule="evenodd"></path></svg>`);
  });
}
function AppointmentsTimeline($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { appointments } = $$props;
    function getColorForStatus(status) {
      switch (status) {
        case "completed":
          return "green";
        case "in-progress":
          return "orange";
        case "upcoming":
          return "blue";
        case "cancelled":
          return "red";
        default:
          return "gray";
      }
    }
    function getIconForStatus(status) {
      switch (status) {
        case "completed":
          return CheckCircleSolid;
        case "in-progress":
          return ClockSolid;
        default:
          return CalendarWeekSolid;
      }
    }
    function getIconForAppointment(status) {
      switch (status) {
        case "routine-checkup":
          return CalendarMonthSolid;
        case "follow-up":
          return CalendarPlusSolid;
        case "consultation":
          return MessagesSolid;
        case "immunization":
          return Syringe;
        case "screening":
          return ClockSolid;
        default:
          return CalendarWeekSolid;
      }
    }
    Timeline($$renderer2, {
      order: "vertical",
      children: ($$renderer3) => {
        $$renderer3.push(`<!--[-->`);
        const each_array = ensure_array_like(appointments);
        for (let index = 0, $$length = each_array.length; index < $$length; index++) {
          let appointment = each_array[index];
          const isLastItem = index === appointments.length - 1;
          const itemColor = getColorForStatus(appointment.status);
          const IconComponent = getIconForStatus(appointment.status);
          const IconComponentAppointment = getIconForAppointment(appointment.app_type);
          {
            let orientationSlot = function($$renderer4) {
              $$renderer4.push(`<span class="absolute bg-blue-200 dark:bg-blue-900 -left-4.5 flex h-6 w-6 items-center justify-center rounded-full dark:ring-gray-900">`);
              if (IconComponentAppointment) {
                $$renderer4.push("<!--[-->");
                IconComponentAppointment($$renderer4, { class: "h-4 w-4 text-blue-600 dark:text-blue-400" });
                $$renderer4.push("<!--]-->");
              } else {
                $$renderer4.push("<!--[!-->");
                $$renderer4.push("<!--]-->");
              }
              $$renderer4.push(`</span>`);
            };
            TimelineItem($$renderer3, {
              title: appointment.title,
              date: appointment.date,
              color: itemColor,
              isLast: isLastItem,
              dateFormat: "full-date",
              classes: { h3: "ml-4" },
              datePrefix: "Released on",
              orientationSlot,
              children: ($$renderer4) => {
                $$renderer4.push(`<div class="pl-4"><p class="mb-2 text-base font-normal text-gray-500 dark:text-gray-400">${escape_html(appointment.notes)}</p> <div class="flex gap-2">`);
                if (IconComponent) {
                  $$renderer4.push("<!--[-->");
                  IconComponent($$renderer4, {
                    class: `h-4 w-4 self-center ${stringify(appointment.status === "completed" ? "text-green-600 dark:text-green-400" : appointment.status === "in-progress" ? "text-orange-600 dark:text-orange-400" : appointment.status === "upcoming" ? "text-blue-600 dark:text-blue-400" : "text-gray-600 dark:text-gray-400")}`
                  });
                  $$renderer4.push("<!--]-->");
                } else {
                  $$renderer4.push("<!--[!-->");
                  $$renderer4.push("<!--]-->");
                }
                $$renderer4.push(` <span${attr_class(` self-center items-center rounded-full px-2.5 py-1 text-xs font-medium ${stringify(appointment.status === "completed" ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300" : appointment.status === "in-progress" ? "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300" : appointment.status === "upcoming" ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300" : "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300")}`)}>${escape_html(appointment.status.replace("-", " "))}</span></div></div>`);
              },
              $$slots: { orientationSlot: true, default: true }
            });
          }
        }
        $$renderer3.push(`<!--]-->`);
      },
      $$slots: { default: true }
    });
  });
}
export {
  AppointmentsTimeline as A
};
