import { n as attr, e as escape_html, s as stringify } from "./index.js";
function DoctorCard($$renderer, $$props) {
  let { imageUrl, name } = $$props;
  $$renderer.push(`<div class="flex my-4 items-center gap-4"><img class="aspect-square object-cover size-12 rounded-full"${attr("src", imageUrl)}${attr("alt", `Avatar for ${stringify(name)}`)}/> <div><div class="text-m font-bold">Dr. ${escape_html(name)}</div></div></div>`);
}
export {
  DoctorCard as D
};
