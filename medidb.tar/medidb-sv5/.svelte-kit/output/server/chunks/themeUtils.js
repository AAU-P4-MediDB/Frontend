import { w as createContext } from "./index.js";
function createSafeContext() {
  const [getRaw, set] = createContext();
  function get() {
    try {
      return getRaw();
    } catch {
      return void 0;
    }
  }
  return [get, set];
}
const [getThemeContext] = createSafeContext();
const [getButtonGroupContext] = createSafeContext();
function getTheme(componentKey) {
  const themeState = getThemeContext();
  const theme = themeState && "value" in themeState ? themeState.value : themeState;
  const finalTheme = theme;
  return finalTheme?.[componentKey];
}
function warnThemeDeprecation(component, names, replacements) {
  return;
}
export {
  getButtonGroupContext as a,
  getTheme as g,
  warnThemeDeprecation as w
};
