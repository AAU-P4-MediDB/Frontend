import { e as escape_html, a as attr_class, s as stringify } from "./index.js";
function CardOverlay($$renderer, $$props) {
  let { children } = $$props;
  $$renderer.push(`<div class="bg-light w-full min-h-full px-6 py-6 rounded-xl"><div class="block"><div class="text-md font-bold">`);
  children?.($$renderer);
  $$renderer.push(`<!----></div></div></div>`);
}
function DefaultCard($$renderer, $$props) {
  let { date, title, description, status } = $$props;
  $$renderer.push(`<div class="flex items-center py-2"><div class="block"><div class="text-sm font-light">${escape_html(date)}</div> <div class="text-md font-bold">${escape_html(title)}</div> <div class="text-sm font-light">${escape_html(description)}</div></div> <span${attr_class(`w-4 h-4 rounded-full flex-none self-center ml-auto bg-${stringify(status)}-600`)}></span></div>`);
}
export {
  CardOverlay as C,
  DefaultCard as D
};
