import { b as attributes, c as clsx, i as derived, d as clsx$1 } from "./index.js";
import { l as label } from "./theme.js";
import { g as getTheme } from "./themeUtils.js";
function Label($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      children,
      color = "gray",
      show = true,
      class: className,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const theme = derived(() => getTheme("label"));
    let base = derived(() => label({ color, class: clsx$1(theme(), className) }));
    if (show) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<label${attributes({ ...restProps, class: clsx(base()) })}>`);
      children($$renderer2);
      $$renderer2.push(`<!----></label>`);
    } else {
      $$renderer2.push("<!--[-1-->");
      children($$renderer2);
      $$renderer2.push(`<!---->`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
export {
  Label as L
};
