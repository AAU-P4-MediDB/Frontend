import { t as setContext, g as getContext, b as attributes, c as clsx, d as clsx$1, e as escape_html, a as attr_class, i as derived } from "./index.js";
import { d as closeButton } from "./theme.js";
const DISMISSABLE_KEY = Symbol("dismissable");
function createDismissableContext(onDismiss) {
  const context = {
    dismiss: onDismiss
  };
  return setContext(DISMISSABLE_KEY, context);
}
function useDismiss() {
  const context = getContext(DISMISSABLE_KEY);
  return context;
}
function CloseButton($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      children,
      color = "gray",
      onclick: onclickorg,
      name = "Close",
      ariaLabel,
      size = "md",
      class: className,
      svgClass,
      $$slots,
      $$events,
      ...restProps
    } = $$props;
    const $$d = derived(() => closeButton({ color, size })), base = derived(() => $$d().base), svg = derived(() => $$d().svg);
    useDismiss();
    if (restProps.href === void 0) {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<button${attributes({
        type: "button",
        ...restProps,
        class: clsx(base()({ class: clsx$1(className) })),
        "aria-label": ariaLabel ?? name
      })}>`);
      if (name) {
        $$renderer2.push("<!--[0-->");
        $$renderer2.push(`<span class="sr-only">${escape_html(name)}</span>`);
      } else {
        $$renderer2.push("<!--[-1-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (children) {
        $$renderer2.push("<!--[0-->");
        children($$renderer2);
        $$renderer2.push(`<!---->`);
      } else {
        $$renderer2.push("<!--[-1-->");
        $$renderer2.push(`<svg${attr_class(clsx(svg()({ class: svgClass })))} fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>`);
      }
      $$renderer2.push(`<!--]--></button>`);
    } else {
      $$renderer2.push("<!--[-1-->");
      $$renderer2.push(`<a${attributes({
        ...restProps,
        class: clsx(base()({ class: clsx$1(className) })),
        "aria-label": ariaLabel ?? name
      })}>`);
      if (name) {
        $$renderer2.push("<!--[0-->");
        $$renderer2.push(`<span class="sr-only">${escape_html(name)}</span>`);
      } else {
        $$renderer2.push("<!--[-1-->");
      }
      $$renderer2.push(`<!--]--> `);
      if (children) {
        $$renderer2.push("<!--[0-->");
        children($$renderer2);
        $$renderer2.push(`<!---->`);
      } else {
        $$renderer2.push("<!--[-1-->");
        $$renderer2.push(`<svg${attr_class(clsx(svg()()))} fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>`);
      }
      $$renderer2.push(`<!--]--></a>`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
export {
  CloseButton as C,
  createDismissableContext as c
};
