import { g as goto } from "./client.js";
function GreyButton($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { href = "/", buttonAction = () => goto(), children } = $$props;
    $$renderer2.push(`<button class="h-10 w-full my-4 text-gray-800 font-bold bg-light rounded-lg shadow-md hover:bg-dark hover:text-white duration-300 ease-in-out">`);
    children?.($$renderer2);
    $$renderer2.push(`<!----></button>`);
  });
}
export {
  GreyButton as G
};
