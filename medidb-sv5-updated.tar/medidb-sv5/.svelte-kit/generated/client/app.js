export { matchers } from './matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9'),
	() => import('./nodes/10'),
	() => import('./nodes/11'),
	() => import('./nodes/12'),
	() => import('./nodes/13'),
	() => import('./nodes/14'),
	() => import('./nodes/15'),
	() => import('./nodes/16'),
	() => import('./nodes/17')
];

export const server_loads = [];

export const dictionary = {
		"/": [~4],
		"/(internal)/calendar": [6,[3]],
		"/(internal)/componentExamples": [7,[3]],
		"/(internal)/home": [8,[3]],
		"/(external)/login": [5,[2]],
		"/(internal)/patients": [9,[3]],
		"/(internal)/patients/dashboard": [10,[3]],
		"/(internal)/patients/overview": [11,[3]],
		"/(internal)/patients/permissions": [12,[3]],
		"/(internal)/patients/test_results": [13,[3]],
		"/(internal)/settings": [14,[3]],
		"/(internal)/settings/admin/doctor": [15,[3]],
		"/(internal)/settings/admin/patient": [16,[3]],
		"/(internal)/settings/admin/system": [17,[3]]
	};

export const hooks = {
	handleError: (({ error }) => { console.error(error) }),
	
	reroute: (() => {}),
	transport: {}
};

export const decoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.decode]));
export const encoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.encode]));

export const hash = false;

export const decode = (type, value) => decoders[type](value);

export { default as root } from '../root.js';