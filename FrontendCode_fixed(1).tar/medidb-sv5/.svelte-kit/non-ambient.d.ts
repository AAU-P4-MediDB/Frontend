
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/(internal)" | "/(external)" | "/" | "/api" | "/api/auth" | "/api/auth/login" | "/api/dpm" | "/api/dpm/usrup" | "/api/dpm/usrup/[uuid]" | "/api/dpm/usrup/[uuid]/[type]" | "/(internal)/calendar" | "/(internal)/home" | "/(external)/login" | "/(internal)/patients" | "/(internal)/patients/dashboard" | "/(internal)/patients/overview" | "/(internal)/patients/permissions" | "/(internal)/patients/test_results" | "/(internal)/settings" | "/(internal)/settings/admin" | "/(internal)/settings/admin/doctor" | "/(internal)/settings/admin/patient" | "/(internal)/settings/admin/system";
		RouteParams(): {
			"/api/dpm/usrup/[uuid]": { uuid: string };
			"/api/dpm/usrup/[uuid]/[type]": { uuid: string; type: string }
		};
		LayoutParams(): {
			"/(internal)": Record<string, never>;
			"/(external)": Record<string, never>;
			"/": { uuid?: string; type?: string };
			"/api": { uuid?: string; type?: string };
			"/api/auth": Record<string, never>;
			"/api/auth/login": Record<string, never>;
			"/api/dpm": { uuid?: string; type?: string };
			"/api/dpm/usrup": { uuid?: string; type?: string };
			"/api/dpm/usrup/[uuid]": { uuid: string; type?: string };
			"/api/dpm/usrup/[uuid]/[type]": { uuid: string; type: string };
			"/(internal)/calendar": Record<string, never>;
			"/(internal)/home": Record<string, never>;
			"/(external)/login": Record<string, never>;
			"/(internal)/patients": Record<string, never>;
			"/(internal)/patients/dashboard": Record<string, never>;
			"/(internal)/patients/overview": Record<string, never>;
			"/(internal)/patients/permissions": Record<string, never>;
			"/(internal)/patients/test_results": Record<string, never>;
			"/(internal)/settings": Record<string, never>;
			"/(internal)/settings/admin": Record<string, never>;
			"/(internal)/settings/admin/doctor": Record<string, never>;
			"/(internal)/settings/admin/patient": Record<string, never>;
			"/(internal)/settings/admin/system": Record<string, never>
		};
		Pathname(): "/" | "/api/auth/login" | `/api/dpm/usrup/${string}/${string}` & {} | "/calendar" | "/home" | "/login" | "/patients" | "/patients/dashboard" | "/patients/overview" | "/patients/permissions" | "/patients/test_results" | "/settings" | "/settings/admin/doctor" | "/settings/admin/patient" | "/settings/admin/system";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/favicon.png" | "/favicon.png~" | string & {};
	}
}