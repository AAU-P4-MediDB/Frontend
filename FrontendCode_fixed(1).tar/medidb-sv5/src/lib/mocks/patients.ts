/*
 * DISCLAIMER: All personal identifiers, including CPR numbers, contained within this file
 * are fictitious and randomly generated for testing purposes only. No data in this file
 * relates to or is capable of identifying any natural person, whether directly or indirectly.
 * Accordingly, this data does not constitute "personal data" within the meaning of Article 4(1)
 * of the General Data Protection Regulation (EU) 2016/679, as it falls outside the scope
 * of the GDPR in accordance with Recital 26 thereof.
 */

import type { Patient } from "../types";

const JANE_DOE_UUID = "9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d";
const JOHN_DOE_UUID = "a2b3c4d5-e6f7-g8h9-i0j1-k2l3m4n5o6p7";
const NORTH_CLINIC_UUID = "north-clinic-uuid";

const PFP = "https://www.nicepng.com/png/full/367-3671905_person-icon-person-icon-silhouette.png";

export const MOCK_PATIENTS: Patient[] = [
  {
    uuid: "p-001",
    name: "John Alexander doe",
    dob: "1972-04-12",
    cpr_key: 4817,
    bio_gender: true,
    pronouns: "he/him",
    clinic: NORTH_CLINIC_UUID,
    doctor: JANE_DOE_UUID,
    weight: 88.2,
    height: 182,
    diagnoses: ["Hypertension"],
    vitals: {
      date: 1711281600,
      "heart rate": "72 bpm",
      "blood pressure": "140/90",
      Sp02: "97%",
    },
    prescriptions: { active: ["Lisinopril"] },
    pfp: PFP,
  },
  {
    uuid: "p-002",
    name: "John Benjamin Doe ",
    dob: "1972-08-25", // Age 54
    cpr_key: 2953,
    bio_gender: true,
    pronouns: "he/him",
    clinic: NORTH_CLINIC_UUID,
    doctor: JANE_DOE_UUID,
    weight: 75.0,
    height: 178,
    diagnoses: ["Asthma"],
    vitals: {
      date: 1711281600,
      "heart rate": "68 bpm",
      "blood pressure": "120/80",
      Sp02: "99%",
    },
    prescriptions: { active: ["Albuterol"] },
    pfp: PFP,
  },
  {
    uuid: "p-003",
    name: "John Christopher Doe",
    dob: "1997-01-15", // Age 29
    cpr_key: 7341,
    bio_gender: true,
    pronouns: "he/him",
    clinic: NORTH_CLINIC_UUID,
    doctor: JANE_DOE_UUID,
    weight: 70.5,
    height: 175,
    diagnoses: ["Routine Checkup"],
    vitals: {
      date: 1711281600,
      "heart rate": "62 bpm",
      "blood pressure": "118/75",
      Sp02: "99%",
    },
    prescriptions: { active: [] },
    pfp: PFP,
  },
  {
    uuid: "p-004",
    name: "Jane Daniel Doe",
    dob: "1991-03-30", // Age 35
    cpr_key: 6028,
    bio_gender: false,
    pronouns: "she/her",
    clinic: NORTH_CLINIC_UUID,
    doctor: JOHN_DOE_UUID, // Updated
    weight: 62.0,
    height: 165,
    diagnoses: ["Anemia"],
    vitals: {
      date: 1711281600,
      "heart rate": "75 bpm",
      "blood pressure": "110/70",
      Sp02: "98%",
    },
    prescriptions: { active: ["Iron Supplement"] },
    pfp: PFP,
  },
  {
    uuid: "p-005",
    name: "Jane Edward Doe",
    dob: "1991-07-11", // Age 35
    cpr_key: 1765,
    bio_gender: true,
    pronouns: "he/him",
    clinic: NORTH_CLINIC_UUID,
    doctor: JANE_DOE_UUID,
    weight: 80.0,
    height: 180,
    diagnoses: ["Vitamin D Deficiency"],
    vitals: {
      date: 1711281600,
      "heart rate": "70 bpm",
      "blood pressure": "122/82",
      Sp02: "98%",
    },
    prescriptions: { active: ["Vitamin D3"] },
    pfp: PFP,
  },
  {
    uuid: "p-006",
    name: "Jane Sofia Doe",
    dob: "1989-12-05", // Age 37
    cpr_key: 8462,
    bio_gender: false,
    pronouns: "she/her",
    clinic: NORTH_CLINIC_UUID,
    doctor: JOHN_DOE_UUID, // Updated
    weight: 68.5,
    height: 168,
    diagnoses: ["Migraine"],
    vitals: {
      date: 1711281600,
      "heart rate": "78 bpm",
      "blood pressure": "115/75",
      Sp02: "99%",
    },
    prescriptions: { active: ["Sumatriptan"] },
    pfp: PFP,
  },
  {
    uuid: "p-007",
    name: "John Edward Doe",
    dob: "1986-02-18", // Age 40
    cpr_key: 3509,
    bio_gender: true,
    pronouns: "he/him",
    clinic: NORTH_CLINIC_UUID,
    doctor: JANE_DOE_UUID,
    weight: 92.0,
    height: 185,
    diagnoses: ["Lower Back Pain"],
    vitals: {
      date: 1711281600,
      "heart rate": "71 bpm",
      "blood pressure": "128/84",
      Sp02: "97%",
    },
    prescriptions: { active: ["Ibuprofen"] },
    pfp: PFP,
  },
  {
    uuid: "p-008",
    name: "Jane Frederick Doe",
    dob: "2000-05-22", // Age 26
    cpr_key: 9174,
    bio_gender: false,
    pronouns: "she/her",
    clinic: NORTH_CLINIC_UUID,
    doctor: JANE_DOE_UUID,
    weight: 58.0,
    height: 162,
    diagnoses: ["Routine Screening"],
    vitals: {
      date: 1711281600,
      "heart rate": "65 bpm",
      "blood pressure": "112/72",
      Sp02: "100%",
    },
    prescriptions: { active: [] },
    pfp: PFP,
  },
  {
    uuid: "p-009",
    name: "Jane Lee Doe",
    dob: "1999-09-09",
    cpr_key: 5236,
    bio_gender: false,
    pronouns: "she/her",
    clinic: NORTH_CLINIC_UUID,
    doctor: JOHN_DOE_UUID, // Updated
    weight: 55.5,
    height: 160,
    diagnoses: ["Allergic Rhinitis"],
    vitals: {
      date: 1711281600,
      "heart rate": "74 bpm",
      "blood pressure": "110/68",
      Sp02: "99%",
    },
    prescriptions: { active: ["Loratadine"] },
    pfp: PFP,
  },
  {
    uuid: "p-010",
    name: "John George Doe",
    dob: "1969-11-30",
    cpr_key: 7683,
    bio_gender: true,
    pronouns: "he/him",
    clinic: NORTH_CLINIC_UUID,
    doctor: JOHN_DOE_UUID, // Updated
    weight: 95.2,
    height: 188,
    diagnoses: ["Type 2 Diabetes"],
    vitals: {
      date: 1711281600,
      "heart rate": "76 bpm",
      "blood pressure": "135/85",
      Sp02: "96%",
    },
    prescriptions: { active: ["Metformin"] },
    pfp: PFP,
  },
  {
    uuid: "p-011",
    name: "Jane Scarlet Doe",
    dob: "1994-06-14",
    cpr_key: 2041,
    bio_gender: false,
    pronouns: "she/her",
    clinic: NORTH_CLINIC_UUID,
    doctor: JOHN_DOE_UUID, // Updated
    weight: 64.0,
    height: 170,
    diagnoses: ["Post-Op Recovery"],
    vitals: {
      date: 1711281600,
      "heart rate": "72 bpm",
      "blood pressure": "118/78",
      Sp02: "98%",
    },
    prescriptions: { active: ["Oxycodone (Temporary)"] },
    pfp: PFP,
  },
  {
    uuid: "p-012",
    name: "John James Doe",
    dob: "1972-12-24",
    cpr_key: 8315,
    bio_gender: true,
    pronouns: "he/him",
    clinic: NORTH_CLINIC_UUID,
    doctor: JOHN_DOE_UUID, // Updated
    weight: 85.0,
    height: 180,
    diagnoses: ["Hyperlipidemia"],
    vitals: {
      date: 1711281600,
      "heart rate": "69 bpm",
      "blood pressure": "125/82",
      Sp02: "98%",
    },
    prescriptions: { active: ["Atorvastatin"] },
    pfp: PFP,
  },
];
